<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Cleaning Pro
 */
?>
<div id="footer-wrapper">   
	<div class="container"> 
    	
		<?php if( of_get_option('footcols',true) == 'foocolstwo' ){ ?>
            <div class='footer-cols-two'>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-1'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-2'); ?></div><div class="clear"></div>
            </div>
        <?php } elseif ( of_get_option('footcols',true) == 'foocolsthree' ) { ?>
            <div class='footer-cols-three'>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-1'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-2'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-3'); ?></div><div class="clear"></div>
            </div>
        <?php } else { ?>
            <div class='footer-cols-four'>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-1'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-2'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-3'); ?></div>
                <div class="foo-cols widget-column"><?php dynamic_sidebar('footer-4'); ?></div><div class="clear"></div>
            </div>
        <?php } ?>
    
	</div><!--footer padding -->
</div><!-- footer-wrapper --> 

<div class="copyright-wrapper">
	<div class="container">
        <div class="flex-element">
            <div class="copyright-text"><?php echo ''.of_get_option('copyrighttext',true).''; ?></div>
            <div class="designby-text"><?php echo ''.of_get_option('designbytext',true).''; ?></div>
        </div><!-- flex-element -->
    </div><!-- copyright padding -->
</div><!-- copyright-wrapper -->

<?php if( of_get_option('backtotop') != '') { echo do_shortcode(of_get_option('backtotop')); } ; ?>

<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery('#mixitup').mixitup({
		animation: {
			effects: 'fade translateZ(-100px)', /* fade scale */
			duration: 700, /* 600 */
			easing: 'ease-in-out'
		},
	});
    jQuery('#mixitupgal').mixitup({
		animation: {
			effects: 'fade translateZ(-100px)', /* fade scale */
			duration: 700, /* 600 */
			easing: 'ease-in-out'
		},
	});
	if(jQuery(window).width() >= 1170){
	  new WOW().init();
	}
});	
</script>

<?php wp_footer(); ?>
</div>
</body>
</html>