<div class="slider-main">
    <?php
        $slAr = array();
        $m = 0;
        for ($i=1; $i<11; $i++) {
            if ( of_get_option('slide'.$i, true) != "" ) {
                $imgSrc     = of_get_option('slide'.$i, true);                  
                if ( strlen($imgSrc) > 10 ) {
                    $slAr[$m]['image_src'] = of_get_option('slide'.$i, true);
                    $slAr[$m]['image_button'] = of_get_option('slidebutton'.$i, true);
                    $slAr[$m]['image_url'] = of_get_option('slidelink'.$i, true);
                    $m++;
                }
            }
        }
        $slideno = array();
        if( $slAr > 0 ){ $n = 0;
    ?>
    <?php 
        $caption_text = ''; 
        if( of_get_option('sldtxt',true) == 'left' ){ 
            $caption_text = ' caption-text-left';
        } elseif( of_get_option('sldtxt',true) == 'center' ){
            $caption_text = ' caption-text-center';
        }else{
            $caption_text = ' caption-text-right';
        }
    ?>
    <div id="slider" class="nivoSlider<?php echo $caption_text; ?>">
        <?php foreach( $slAr as $sv ){ $n++; ?>
            <img src="<?php echo esc_url($sv['image_src']); ?>" alt="<?php echo esc_attr($sv['image_button']);?>" class="nivo-overlay" title="<?php echo '#slidecaption'.$n; ?>" />
        <?php $slideno[] = $n; } ?>
    </div>
    <?php foreach( $slideno as $sln ){ ?>
        <div id="slidecaption<?php echo $sln; ?>" class="nivo-html-caption">
            <?php if( of_get_option('slidetitle'.$sln, true) != '' ){ ?>
                <a href="<?php echo of_get_option('slideurl'.$sln, true); ?>"><h2><?php echo of_get_option('slidetitle'.$sln, true); ?></h2></a>
            <?php } ?>
            <?php if( of_get_option('slidedes'.$sln, true) != '' ){ ?>
                <p><?php echo of_get_option('slidedes'.$sln, true); ?></p><div class="clear"></div>
            <?php } ?>
            <?php if( of_get_option('slideurl'.$sln, true) != '' ){ ?>
                <a href="<?php echo of_get_option('slideurl'.$sln, true); ?>" class="sliderbtn">
                    <span><?php echo of_get_option('slidebutton'.$sln, true); ?></span>
                </a>
            <?php } ?>
        </div><!-- nivo-html-caption -->
    <?php } } ?>
</div><!-- slider main-->