<?php
 // Load responsive header
?>
<header class="header-responsive">
    <?php 
        if( of_get_option('tophead',true) == 'show' ) {
            echo '<div class="top-header-toggle"><a href="#" class="tp-head-toggle main-button"><i class="far fa-chevron-down"></i></a></div>';
            get_template_part('header/top','header');
        }
    ?>
	<div class="container">
    	<div class="logo">
        	<?php if(of_get_option('logo',true) == 1) { ?>
             <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                  <p><?php bloginfo('description'); ?></p>
             <?php } elseif( of_get_option( 'logo', true ) != '' ) { ?>
             <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( of_get_option( 'logo', true )); ?>" / ></a>
             <?php } else { ?>
             <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                  <p><?php bloginfo('description'); ?></p>
             <?php } ?>
        </div><!-- Logo -->
        <div class="toggle">
            <a class="toggleMenu" href="#"></a>
        </div><!-- toggle --><div class="clear"></div>
        <div class="sitenav">                   
            <div class="container">
                <?php wp_nav_menu( array('theme_location' => 'primary', 'link_before' => '<span>', 'link_after' => '</span>',) ); ?>
                <?php if( of_get_option('headbtnhead',true) == 'show' ) { ?>
                    <div class="header-btn">
                        <a href="<?php echo of_get_option('headbtnlink',true);?>" class="main-button"><?php echo of_get_option('headbtntxt',true);?></a>
                    </div>    
                <?php } ?>                
            </div>
        </div><!--.sitenav -->
    </div><!-- container -->
</header><!-- header responsive -->