<?php
    if( is_home() || is_front_page() ){
        if( ( of_get_option( 'homepageslider',true ) != 'hide' ) ){
            if( of_get_option('customslider',true) == '' ){
                get_template_part('header/inner-parts/has','slider');
            } else {
                $short_code = of_get_option('customslider');
                echo do_shortcode($short_code);                
            }
        } else {
            $header_image = get_header_image();
            if(!empty($header_image)){
                echo '<div class="innerbanner" style="background:url('.esc_url( $header_image ).' ) no-repeat scroll center center; background-size:cover;"><div class="show-header-image"></div></div>';
            }
        }
    } else {
        if ( ( of_get_option('innerpageslider', true) != 'hide' ) ) {
            if( of_get_option('customslider',true) == '' ){
                get_template_part('header/inner-parts/has','slider');
                get_template_part('header/inner-parts/title-without','banner');
            } else {
                $short_code = of_get_option('customslider');
                echo do_shortcode($short_code);
                get_template_part('header/inner-parts/title-without','banner');
            }
        } else{
            if( of_get_option( 'hidepagebanner',true ) == '' ) {
                get_template_part('header/inner-parts/title-with','banner');
            } else {
                get_template_part('header/inner-parts/title-without','banner');
            }
        }
    }
?>