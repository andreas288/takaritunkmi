<div class="top-header">
    <div class="container">
        <div class="side-border">
            <div class="flex-element">

                <?php if( !empty( of_get_option('tpheadtxt',true) ) ) { ?>
                    <div class="top-header-col big">
                        <?php echo of_get_option('tpheadtxt',true); ?>
                    </div>
                <?php } if( !empty( of_get_option('tpheadscl',true) ) ) { ?>
                    <div class="top-header-col big text-center">
                        <?php echo do_shortcode(''.of_get_option('tpheadscl',true).''); ?>
                    </div>
                <?php } if( !empty( of_get_option('tpheadphn',true) ) ) { ?>
                    <div class="top-header-col small text-right icon-phn">
                        <a href="mailto:<?php echo of_get_option('tpheadphn',true); ?>"><?php echo of_get_option('tpheadphn',true); ?></a>
                    </div>
                <?php } if( !empty( of_get_option('tpheadmail',true) ) ) { ?>
                    <div class="top-header-col small text-right icon-mail">
                        <a href="mailto:<?php echo of_get_option('tpheadmail',true); ?>"><?php echo of_get_option('tpheadmail',true); ?></a>
                    </div>
                <?php } ?>
                
            </div><!-- flex elements -->
        </div><!-- side border -->
    </div><!-- container -->
</div><!-- top header -->