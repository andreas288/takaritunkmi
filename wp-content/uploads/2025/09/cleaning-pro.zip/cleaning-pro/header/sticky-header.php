<div class="sticky-header">
	<div class="container">
        <div class="flex-element">
            <div class="sticky-left">
                <div class="logo">
                    <?php if(of_get_option('stckylogo',true) == 1) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                        <p><?php bloginfo('description'); ?></p>
                    <?php } elseif( of_get_option( 'stckylogo', true ) != '' ) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( of_get_option( 'stckylogo', true )); ?>" / ></a>
                    <?php } else { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                        <p><?php bloginfo('description'); ?></p>
                    <?php } ?>
                </div><!-- logo -->
            </div><!-- sticky-left -->
            <div class="sticky-right">
                <div class="sitenav">
                    <?php wp_nav_menu( array('theme_location' => 'primary', 'link_before' => '<span>', 'link_after' => '</span>',) ); ?>
                </div><!-- sitenav -->
            </div><!-- sticky right --><div class="clear"></div>
        </div><!-- flex element -->
    </div><!-- container -->
</div><!-- sticky-header -->