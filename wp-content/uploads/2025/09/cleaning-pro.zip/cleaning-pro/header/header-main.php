<?php
// Load Main Header
?>
<div class="header-main"<?php if( !is_home() || !is_front_page() ){if( of_get_option('hidepagebanner',true) != ''){ if( of_get_option('innerpageslider',true) !='show'){echo' style="position:relative;"';}}}?>>
    <?php // Load sticky header
        if( of_get_option('stickhead',true) == 'enable' ) {
            get_template_part('header/sticky','header');
        }
        // Load Top header
        if( of_get_option('tophead',true) == 'show' ) {
            get_template_part('header/top','header');
        }
    ?>
    <header class="header">
        <div class="container">
            <div class="flex-element">

                <div class="header-left">
                    <div class="logo">
                        <?php if(of_get_option('logo',true) == 1) { ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                            <p><?php bloginfo('description'); ?></p> 
                        <?php } elseif( of_get_option( 'logo', true ) != '' ) { ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( of_get_option( 'logo', true )); ?>" / ></a>
                        <?php } else { ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1><?php bloginfo('name'); ?></h1></a>
                            <p><?php bloginfo('description'); ?></p>
                        <?php } ?>
                    </div><!-- .logo -->
                </div><!-- header left -->
                <div class="header-right"<?php if( of_get_option('headbtnhead',true) != 'show' ) { ?> style="width:77%;"<?php } ?>>
                    <div class="toggle">
                        <a class="toggleMenu" href="#"></a>
                    </div><!-- toggle -->
                    <div class="sitenav">
                        <?php wp_nav_menu( array('theme_location' => 'primary', 'link_before' => '<span>', 'link_after' => '</span>',) ); ?>
                    </div><!--.sitenav -->
                </div><!-- header right -->

                <?php if( of_get_option('headbtnhead',true) == 'show' ) { ?>
                    <div class="header-btn">
                        <a href="<?php echo of_get_option('headbtnlink',true);?>" class="main-button"><?php echo of_get_option('headbtntxt',true);?></a>
                    </div>    
                <?php } ?>
                
            </div><!-- flex elements -->
        </div><!-- container -->
    </header><!-- header -->
</div><!-- header main -->