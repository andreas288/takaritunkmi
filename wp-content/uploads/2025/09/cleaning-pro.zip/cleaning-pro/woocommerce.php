<?php get_header(); 
if( of_get_option('woocommercelayout',true) != ''){
	$woocommercelayout = of_get_option('woocommercelayout');
}
?>

<div class="container content-area">
      <div id="sitemain" class="site-main <?php echo $woocommercelayout; ?>" >       
		<?php woocommerce_content(); ?>             
      </div>
      
     <?php if( $woocommercelayout != 'woocommercesitefull' ){?>
     	<div id="sidebar" <?php if( of_get_option('woocommercelayout', true) == 'woocommerceleft' ){ echo 'style="float:left;"'; }?>>
     	 	<?php dynamic_sidebar('shop'); ?>
        </div>    
	 <?php } ?>
 	<div class="clear"></div>
  </div>
<?php get_footer(); ?>