<?php 
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 */ 

function optionsframework_option_name() {
	// Change this to use your theme slug
	$themename = wp_get_theme();
	$themename = preg_replace("/\W/", "_", strtolower($themename) );
	return $themename;
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'cleaning'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
*/

function optionsframework_options() {
	
	$options = array();
	$imagepath =  get_template_directory_uri() . '/images/';
	
	// Pull all the pages into an array
	 $options_pages = array();
	 $options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	 $options_pages[''] = 'Select a page:';
	 foreach ($options_pages_obj as $page) {
	  $options_pages[$page->ID] = $page->post_title;
	 }

	// array of section content.
	$section_text = array(
		1=> Array(
			'section_class' => 'container',
			'section_sub_title' => '',
			'section_title' => '',
			'section_text'	=> '',
			'bgcolor' 		=> '#ffffff',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[column_content type="one_third" subcls="section-title-nbdr"][section_title sub_title="WELCOME TO OUR" title="CLEANING SERVICES"] Suspendisse nisl ex, interdum sed libero vitae, convallis elementum mi. Vestibulum odio ante, accumsan id risus imperdiet, venenatis lobortis mi. In non nisi mi. Curabitur tempus, erat eu porta hendrerit, eros quam ullamcorper leo, sed lacinia neque urna nec urna.  
			[button name="Read More" align="left" link="/about"][/column_content][column_content type="one_third"][icon_box icon="bookmark" icon_style="light" title="Flexible Cleaning Plans" link="#"] venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. [/icon_box][icon_box icon="leaf" icon_style="solid" title="Green Cleaning Solution" link="#"] venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. [/icon_box][/column_content][column_content type="one_third_last"][icon_box icon="user" icon_style="light" title="Verified Employees" link="#"] venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. [/icon_box][icon_box icon="life-ring" icon_style="regular" title="Best Customer Support" link="#"] venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. [/icon_box][/column_content][clear]',
		),
		2=> Array(
			'section_class' => 'container',
			'section_sub_title' => '',
			'section_title' => '',
			'section_text'	=> '',
			'bgcolor' 		=> '#f8f8f8',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[introduction image="'.$imagepath.'intro.jpg" image_position="right" title="High Quality & Best Cleaning Services" sub_title="A Trusted Cleaning Company" button_text="Read More" link="#"] Suspendisse nisl ex, interdum sed libero vitae, convallis elementum mi. Vestibulum odio ante, accumsan id risus imperdiet, venenatis lobortis mi. In non nisi mi. Curabitur tempus, erat eu porta hendrerit, eros quam ullamcorper leo, sed lacinia neque urna nec urna.

			Suspendisse eu ultrices dui, in lobortis odio. Duis ac lobortis elit. Phasellus nec nulla vel massa dignissim sagittis vitae vel ipsum. Cras aliquam lorem et erat pulvinar posuere. Duis tortor risus, sodales non neque at, auctor mollis dolor. Ut at ipsum tellus. 

			<ul class="intro-list"><li><a href="#">Residential Cleaning</a></li><li><a href="#">Office Cleaning</a></li><li><a href="#">Construction Cleaning</a></li><li><a href="#">Commercial Cleaning</a></li><li><a href="#">Wall Painting</a></li><li><a href="#">Seasonal Cleaning</a></li></ul>[/introduction]',
		),
		3=> Array(
			'section_class' => 'container',
			'section_sub_title' => 'A Trusted Cleaning Company',
			'section_title' => 'High Quality & Best Cleaning Services',
			'section_text'	=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[column_content type="one_third"][image_box image="'.$imagepath.'service-1.jpg" title="Window Cleaning" button_text="View Service" link="#"] Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  [/image_box][/column_content][column_content type="one_third"][image_box image="'.$imagepath.'service-2.jpg" title="Home Cleaning" button_text="View Service" link="#"] Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  [/image_box][/column_content][column_content type="one_third_last"][image_box image="'.$imagepath.'service-3.jpg" title="Floor Cleaning" button_text="View Service" link="#"] Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  [/image_box][/column_content][clear]',
		),
		4=> Array(
			'section_class' => 'container',
			'section_sub_title' => '',
			'section_title' => '',
			'section_text'	=> '',
			'bgcolor' 		=> '#27c9f7',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[counter_wrap][counter title="Projects Finished" count="600" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Satisfied Customers" count="1450" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Branches Network" count="60" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Cleaning Tips" count="3000" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Free Quotes Sent" count="900" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][/counter_wrap]',
		),
		5=> Array(
			'section_class' => 'container',
			'section_sub_title' => 'Experienced & Talented',
			'section_title' => 'Our Team',
			'section_text'	=> '',
			'bgcolor' 		=> '#f8f8f8',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[our-team type="grid" show="-1" column="4"]',
		),
		6=> Array(
			'section_class' => 'full-container',
			'section_sub_title' => 'Projects & Portfolio',
			'section_title' => 'Our Gallery',
			'section_text'	=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> '',
			'class'			=> 'pb-0',
			'content'		=> '[photo-gallery show="8" type="grid" column="4"]',
		),
		7=> Array(
			'section_class' => 'container',
			'section_sub_title' => 'What Clients Say',
			'section_title' => 'Client Testimonials',
			'section_text'	=> '',
			'bgcolor' 		=> '#f8f8f8',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[testimonials show="4"]',
		),
		8=> Array(
			'section_class' => 'container',
			'section_sub_title' => 'News & Events',
			'section_title' => 'Our Latest Posts',
			'section_text'	=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[latest-news show="3" type="grid" column="3" comment="show" date="show" author="show" category="show"]',
		),
	);

	$options = array();

	//Basic Settings
	$options[] = array(
		'name' => __('Basic Settings', 'cleaning'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('Main Logo', 'cleaning'),
		'desc' => __('Upload your main logo here', 'cleaning'),
		'id' => 'logo',
		'std'	=> $imagepath.'logo.png',
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('Sticky Logo', 'cleaning'),
		'desc' => __('Upload your sticky header logo here', 'cleaning'),
		'id' => 'stckylogo',
		'std'	=> '',
		'type' => 'upload');
		
	$options[] = array(			
		'desc'	=> __('Check To View Box Layout ', 'cleaning'),
		'id'	=> 'boxlayout',
		'type'	=> 'checkbox',
		'std'	=> '');			
		
	$options[] = array(
		'name' => __('Custom CSS', 'cleaning'),
		'desc' => __('Some Custom Styling for your site. Place any css codes here instead of the style.css file.', 'cleaning'),
		'id' => 'style2',
		'std' => '',
		'type' => 'textarea');
	
	$options[] = array(
		'name' => __('Enable / Disable Gutenberg editor', 'cleaning'),
		'desc' => __('enable / disable gutenber editor for page and posts.', 'cleaning'),
		'id' => 'gutenonoff',
		'type' => 'select',
		'std' => 'disable',
		'options' => array('enable'=>'Enable', 'disable'=>'Disable') );

	$options[] = array(
		'name' => __('Enable / Disable sticky header', 'cleaning'),
		'desc' => __('enable / disable sticky header.', 'cleaning'),
		'id' => 'stickhead',
		'type' => 'select',
		'std' => 'disable',
		'options' => array('enable'=>'Enable', 'disable'=>'Disable') );

	$options[] = array(
		'name' => __('Top Header', 'cleaning'),
		'desc' => __('Show / Hide top header.', 'cleaning'),
		'id' => 'tophead',
		'type' => 'select',
		'std' => 'show',
		'options' => array('show'=>'Show', 'hide'=>'Hide') );

	$options[] = array(
		'desc' => __('Add top header text here', 'cleaning'),
		'id' => 'tpheadtxt',
		'std' => 'Professional Cleaning Services For all Your Need',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add top header social icon here.', 'cleaning'),
		'id' => 'tpheadscl',
		'std' => '[social_area][social icon="twitter" link="#"][social icon="facebook-f" link="#"][social icon="youtube" link="#"][social icon="linkedin-in" link="#"][social icon="pinterest-p" link="#"][/social_area]',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Add top header contact number', 'cleaning'),
		'id' => 'tpheadphn',
		'std' => '+01 888 888 8888',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add top header email address', 'cleaning'),
		'id' => 'tpheadmail',
		'std' => 'info@sitename.com',
		'type' => 'text');

	$options[] = array(
		'name' => __('Request A Qoute Button', 'cleaning'),
		'desc' => __('Add text for header quote button', 'cleaning'),
		'id' => 'headbtntxt',
		'type' => 'text',
		'std' => 'Request A Quote');

	$options[] = array(
		'desc' => __('Add link for header quote button', 'cleaning'),
		'id' => 'headbtnlink',
		'type' => 'text',
		'std' => '#');

	$options[] = array(
		'desc' => __('Show / Hide header quote button.', 'cleaning'),
		'id' => 'headbtnhead',
		'type' => 'select',
		'std' => 'show',
		'options' => array('show'=>'Show', 'hide'=>'Hide') );
	
	// Typography Body
	$typography_body = array(
		'size' => '13px',
		'face' => 'Sintony',
		'weight' => '400',
		'style' => 'normal',
		'color' => '#797878');	
	
	$typography_h1 = array(
		'size' => '34px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
		
	$typography_h2 = array(
		'size' => '26px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
		
	$typography_h3 = array(
		'size' => '22px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
		
	$typography_h4 = array(
		'size' => '18px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
		
	$typography_h5 = array(
		'size' => '16px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
		
	$typography_h6 = array(
		'size' => '14px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
	
	// Typography Logo
	$typography_logo = array(
		'size' => '30px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#494949');
	
	// Typography Tagline
	$typography_tag = array(
		'size' => '14px',
		'face' => 'Karla',
		'weight' => '400',
		'style' => 'normal',
		'color' => '#868686');
		
	// Typography Nav
	$typography_nav = array(
		'size' => '14px',
		'face' => 'Sintony',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#5b5b5b');
		
	// Typography Slider Title
	$typography_slidetitle = array(
		'size' => '40px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#ffffff');
		
	// Typography Slider Description
	$typography_slidedesc = array(
		'size' => '14px',
		'face' => 'Sintony',
		'weight' => '400',
		'style' => 'normal',
		'color' => '#ffffff');

	// Typography Section Sub Title
	$typography_secsbtitle = array(
		'size' => '17px',
		'face' => 'Montserrat',
		'weight' => '500',
		'style' => 'normal',
		'color' => '#a2a2a2');

	// Typography Section Main Title
	$typography_sectitle = array(
		'size' => '25px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
	
	// Typography Testimonial Name
	$typography_testname = array(
		'size' => '16px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#323131');
		
	// Typography Testimonial company Name
	$typography_testcmp = array(
		'size' => '14px',
		'face' => 'Work Sans',
		'weight' => '400',
		'style' => 'normal',
		'color' => '#1c1f26');
	
	// Typography Our Team Title
	$typography_teamtitle = array(
		'size' => '15px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#444444');
	
	// Typography Latest Posts Title
	$typography_lpttl = array(
		'size' => '17px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#282828');
	
	// Typography Footer Title
	$typography_foottitle = array(
		'size' => '18px',
		'face' => 'Montserrat',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#ffffff');
	
	// Typography InnerPage Title 
	$typography_pagetitle = array(
		'size' => '42px',
		'face' => 'Sintony',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#ffffff');
		
	// Typography Widget Title
	$typography_widgettitle = array(
		'size' => '20px',
		'face' => 'Oswald',
		'weight' => '400',
		'style' => 'normal',
		'color' => '#131313');
	
	// Typography Product Title
	$typography_prodtitle = array(
		'size' => '18px',
		'face' => 'Roboto Condensed',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#1c1f26');

	// Typography Single Product Title
	$typography_singleprodtitle = array(
		'size' => '26px',
		'face' => 'Roboto Slab',
		'weight' => '700',
		'style' => 'normal',
		'color' => '#1c1f26');

	// font family Start 
	$options[] = array(
		'name' => __('Font Typogarphy', 'cleaning'),
		'desc' => __('Select font family/size/color/weight/style for the body text.', 'cleaning'),
		'id' => 'bodyfontface',
		'type' => 'typography',
		'std' => $typography_body );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h1', 'cleaning'),
		'id' => 'h1fontface',
		'type' => 'typography',
		'std' => $typography_h1 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h2', 'cleaning'),
		'id' => 'h2fontface',
		'type' => 'typography',
		'std' => $typography_h2 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h3', 'cleaning'),
		'id' => 'h3fontface',
		'type' => 'typography',
		'std' => $typography_h3 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h4', 'cleaning'),
		'id' => 'h4fontface',
		'type' => 'typography',
		'std' => $typography_h4 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h5', 'cleaning'),
		'id' => 'h5fontface',
		'type' => 'typography',
		'std' => $typography_h5 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for heading tag h6', 'cleaning'),
		'id' => 'h6fontface',
		'type' => 'typography',
		'std' => $typography_h6 );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the textual logo', 'cleaning'),
		'id' => 'logofontface',
		'type' => 'typography',
		'std' => $typography_logo );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the logo tagline', 'cleaning'),
		'id' => 'tagfontface',
		'type' => 'typography',
		'std' => $typography_tag );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for navigation menu', 'cleaning'),
		'id' => 'navfontface',
		'type' => 'typography',
		'std' => $typography_nav );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for slider Main title', 'cleaning'),
		'id' => 'slidetitlefontface',
		'type' => 'typography',
		'std' => $typography_slidetitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for slider description', 'cleaning'),
		'id' => 'slidedescfontface',
		'type' => 'typography',
		'std' => $typography_slidedesc );

	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the section sub title', 'cleaning'),
		'id' => 'secsbtitlefontface',
		'type' => 'typography',
		'std' => $typography_secsbtitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the section title', 'cleaning'),
		'id' => 'sectitlefontface',
		'type' => 'typography',
		'std' => $typography_sectitle );
	
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for testimonial name', 'cleaning'),
		'id' => 'testnamefontface',
		'type' => 'typography',
		'std' => $typography_testname );

	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for testimonial company name', 'cleaning'),
		'id' => 'testcmpfontface',
		'type' => 'typography',
		'std' => $typography_testcmp );
	
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the Our Team title', 'cleaning'),
		'id' => 'teamtitlefontface',
		'type' => 'typography',
		'std' => $typography_teamtitle );
	
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the Latest Posts Title', 'cleaning'),
		'id' => 'lpttlfontface',
		'type' => 'typography',
		'std' => $typography_lpttl );
	
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the footer Widget title', 'cleaning'),
		'id' => 'foottitlefontface',
		'type' => 'typography',
		'std' => $typography_foottitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the InnerPage title', 'cleaning'),
		'id' => 'pagetitlefontface',
		'type' => 'typography',
		'std' => $typography_pagetitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the widget title', 'cleaning'),
		'id' => 'widgettitlefontface',
		'type' => 'typography',
		'std' => $typography_widgettitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the Product page title', 'cleaning'),
		'id' => 'prodtitlefontface',
		'type' => 'typography',
		'std' => $typography_prodtitle );
		
	$options[] = array(
		'desc' => __('Select font family/size/color/weight/style for the Single Product page title', 'cleaning'),
		'id' => 'singleprodtitlefontface',
		'type' => 'typography',
		'std' => $typography_singleprodtitle );

	// Header colors
	$options[] = array(
		'name' => __('Top Header font / background Colors', 'cleaning'),	
		'desc' => __('Select top header background color', 'cleaning'),
		'id' => 'tpheadbg',
		'std' => '#ffffff',
		'type' => 'color');

	$options[] = array(	
		'desc' => __('Select top header text color', 'cleaning'),
		'id' => 'tpheadtxtclr',
		'std' => '#797878',
		'type' => 'color');

	$options[] = array(	
		'desc' => __('Select top header link color', 'cleaning'),
		'id' => 'tpheadlnk',
		'std' => '#797878',
		'type' => 'color');

	$options[] = array(	
		'desc' => __('Select top header link hover color', 'cleaning'),
		'id' => 'tpheadlnkhv',
		'std' => '#ffd527',
		'type' => 'color');

	$options[] = array(	
		'desc' => __('Select top header border color', 'cleaning'),
		'id' => 'tpheadbdr',
		'std' => '#27c6f2',
		'type' => 'color');
	
	// Header colors
	$options[] = array(
		'name' => __('Default Header font / background Colors', 'cleaning'),	
		'desc' => __('Select background color for header', 'cleaning'),
		'id' => 'headbgclr',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(		
		'desc' => __('Select main header background color for mobile', 'cleaning'),
		'id' => 'mainheadbgclr',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select background color for sticky header', 'cleaning'),
		'id' => 'stickyheadbg',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select font color for navigation hover', 'cleaning'),
		'id' => 'navhovercolor',
		'std' => '#00adef',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font color for toogle navigation icon in mobile', 'cleaning'),
		'id' => 'toogleclr',
		'std' => '#00aeef',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font hover color for toogle navigation icon in mobile', 'cleaning'),
		'id' => 'tooglehvrclr',
		'std' => '#131313',
		'type' => 'color');

	// Fonts Colors
	$options[] = array(
		'name' => __('Font Colors', 'cleaning'),
		'desc' => __('Select section title color with overlay', 'cleaning'),
		'id' => 'ovrlaysecclr',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font hover color for client testimonilas title', 'cleaning'),
		'id' => 'testimonialtitlecolor',
		'std' => '#00aeef',
		'type' => 'color');													
									
	$options[] = array(
		'desc' => __('Select font hover color for team member title', 'cleaning'),
		'id' => 'teamtitlehvclr',
		'std' => '#ffd527',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select font hover color for latest news title', 'cleaning'),
		'id' => 'lnewstitlehvclr',
		'std' => '#ffd527',
		'type' => 'color');		
		
	$options[] = array(
		'desc' => __('Select font hover color for blog page post title', 'cleaning'),
		'id' => 'blogposthoverclr',
		'std' => '#00aeef',
		'type' => 'color');	
	
	// Background Colors
	$options[] = array(
		'name' => __('Background Colors', 'cleaning'),				
		'desc' => __('Select background color for body', 'cleaning'),
		'id' => 'bodybgcolor',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select background color for header nav dropdown', 'cleaning'),
		'id' => 'navdpbgcolor',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select navigation dropdown background color opacity','cleaning'),
		'id' => 'navdrpdwnbgopac',
		'std' => '0.8',
		'type' => 'select',
		'options' => array('1'=>1, '0.9'=>0.9,'0.8'=>0.8,'0.7'=>0.7,'0.6'=>0.6,'0.5'=>0.5,'0.4'=>0.4,'0.3'=>0.3,'0.2'=>0.2, '0.1'=>0.1, '0'=>0,)
	);

	$options[] = array(
		'desc' => __('Select background color for our skill bar', 'cleaning'),
		'id' => 'skillbarbgcolor',
		'std' => '#00aeef',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background active color for our skill bar', 'cleaning'),
		'id' => 'skillbarbgcoloractive',
		'std' => '#ffd527',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select background color for menu in mobile', 'cleaning'),
		'id' => 'mobilemenubg',
		'std' => '#000000',
		'type' => 'color');	
	
	// Links Colors
	$options[] = array(
		'name' => __('Link Colors', 'cleaning'),	
		'desc' => __('Select font color for links / anchor tags', 'cleaning'),
		'id' => 'linkcolor',
		'std' => '#444444',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select font hover color for links / anchor tags', 'cleaning'),
		'id' => 'linkhovercolor',
		'std' => '#ffd527',
		'type' => 'color');	
	
	// Social Icons Colors
	$options[] = array(	
		'name' => __('Social icons colors', 'cleaning'),			
		'desc' => __('Select font color for social icons', 'cleaning'),
		'id' => 'socialfontcolor',
		'std' => '#1c1f26',
		'type' => 'color');		
		
	$options[] = array(
		'desc' => __('Select font hover color for social icons', 'cleaning'),
		'id' => 'socialfonthvcolor',
		'std' => '#ffd527',
		'type' => 'color');

	// Footer Colors
	$options[] = array(
		'name' => __('Footer Background and Font Color', 'cleaning'),
		'desc' => __('Select footer border color', 'cleaning'),
		'id' => 'foobdrclr',
		'std' => '#ffd527',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select footer background color', 'cleaning'),
		'id' => 'foobgclr',
		'std' => '#012c3c',
		'type' => 'color');
				
	$options[] = array(		
		'desc' => __('Select font color for footer description', 'cleaning'),
		'id' => 'footdesccolor',
		'std' => '#c4bec2',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer links', 'cleaning'),
		'id' => 'footerposttitlecolor',
		'std' => '#c4bec2',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font hover color for footer links', 'cleaning'),
		'id' => 'footerposttitlehvcolor',
		'std' => '#ffd527',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select background color for footer copyright', 'cleaning'),
		'id' => 'copybgcolor',
		'std' => '#012c3c',
		'type' => 'color');
					
	$options[] = array(
		'desc' => __('Select font color for footer copyright text', 'cleaning'),
		'id' => 'copycolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer copyright links', 'cleaning'),
		'id' => 'copylinks',
		'std' => '#ffd527',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font hover color for footer copyright links', 'cleaning'),
		'id' => 'copylinkshov',
		'std' => '#ffffff',
		'type' => 'color');
	
	// Overlay Color and Opacity
	$options[] = array(	
		'name' =>__('Overlay Color and opacity', 'cleaning'),					
		'desc' => __('Select overlay color', 'cleaning'),
		'id' => 'overlaycolor',
		'std' => '#000000',
		'type' => 'color');						
	
	$options[] = array(		
		'desc' => __('Select opacity for overlay color', 'cleaning'),
		'id' => 'overlaycoloropacity',
		'std' => '0.7',
		'type' => 'select',
		'options'	=> array('1'=>1, '0.9'=>0.9,'0.8'=>0.8,'0.7'=>0.7,'0.6'=>0.6,'0.5'=>0.5,'0.4'=>0.4,'0.3'=>0.3,'0.2'=>0.2,'0.1'=>0.1,'0'=>0,));
	
	// Main Button ( Default )
	$options[] = array(
		'name' => __('Main Button Color ( Your Theme&#39;s Default Color )', 'cleaning'),
		'desc' => __('Select background color for default button', 'cleaning'),
		'id' => 'btnbgcolor',
		'std' => '#ffd527',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover color for default button', 'cleaning'),
		'id' => 'btnbghvcolor',
		'std' => '#28c6f2',
		'type' => 'color');	
	
	$options[] = array(
		'desc' => __('Select font color default button', 'cleaning'),
		'id' => 'btntxtcolor',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select font hover color for default button', 'cleaning'),
		'id' => 'btntxthvcolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	// Second Butoon Color	
	$options[] = array(
		'name' => __('Second Button Color', 'cleaning'),
		'desc' => __('Select background color for Second button', 'cleaning'),
		'id' => 'cusbtnbgcolor',
		'std' => '#28c6f2',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover color for Second button', 'cleaning'),
		'id' => 'cusbtnbghvcolor',
		'std' => '#ffd527',
		'type' => 'color');		
	
	$options[] = array(
		'desc' => __('Select font color for Second button', 'cleaning'),
		'id' => 'cusbtntxtcolor',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select font hover color for Second button', 'cleaning'),
		'id' => 'cusbtntxthvcolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	// Slider Button Color( Second )
	$options[] = array(
		'name' => __('Slider Button Color', 'cleaning'),
		'desc' => __('Select background color for slider button', 'cleaning'),
		'id' => 'sldrbtnbgcolor',
		'std' => '#eae629',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select text color for slider button', 'cleaning'),
		'id' => 'sldrbtntxtcolor',
		'std' => '#232323',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select background hover color for slider button', 'cleaning'),
		'id' => 'sldrbtnbghvcolor',
		'std' => '#25caf8',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select text hover color for slider button', 'cleaning'),
		'id' => 'sldrbtntxthvcolor',
		'std' => '#ffffff',
		'type' => 'color');	
					
	// Slider controls colors		
	$options[] = array(
		'name' => __('Slider controls Colors', 'cleaning'),
		'desc' => __('Select background color for slider pager', 'cleaning'),
		'id' => 'sldpagebg',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background active color for slider pager', 'cleaning'),
		'id' => 'sldpagehvbg',
		'std' => '#00aeef',
		'type' => 'color');
		
	// Sidebar Colors
	$options[] = array(
		'name' => __('Sidebar/Widget Colors', 'cleaning'),
		'desc' => __('Select font color for sidebar li a', 'cleaning'),
		'id' => 'sidebarfontcolor',
		'std' => '#131313',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font hover color for sidebar li a', 'cleaning'),
		'id' => 'sidebarfonthvcolor',
		'std' => '#ffd527',
		'type' => 'color');
	
	// Tab and Accordian colors
	$options[] = array(	
		'name' => __('Tab And Toggle Colors', 'cleaning'),				
		'desc' => __('Select font color for tab button', 'cleaning'),
		'id' => 'tabttlclr',
		'std' => '#282828',
		'type' => 'color');
		
	$options[] = array(					
		'desc' => __('Select font hover/active color for tab button', 'cleaning'),
		'id' => 'tabttlactvclr',
		'std' => '#ffd527',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font color for tab description', 'cleaning'),
		'id' => 'tabcontentfontcolor',
		'std' => '#000000',
		'type' => 'color');
			
	$options[] = array(	
		'name' => __('Accordion Colors', 'cleaning'),				
		'desc' => __('Select font color for accordion title', 'cleaning'),
		'id' => 'accttlclr',
		'std' => '#1c1f26',
		'type' => 'color');
	
	$options[] = array(				
		'desc' => __('Select font color for active accordion title', 'cleaning'),
		'id' => 'accttlactvclr',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(				
		'desc' => __('Select background color for active accordion title', 'cleaning'),
		'id' => 'accbgactvclr',
		'std' => '#1c1f26',
		'type' => 'color');
	
	$options[] = array(				
		'desc' => __('Select border color for active accordion title', 'cleaning'),
		'id' => 'accactvbrdclr',
		'std' => '#e7e7e7',
		'type' => 'color');
	
	$options[] = array(				
		'desc' => __('Select font color for accordion description', 'cleaning'),
		'id' => 'accdescclr',
		'std' => '#6e6d6d',
		'type' => 'color');
	
	//Back to top
	$options[] = array(
		'name' => __('Back To Top Icon and color', 'cleaning'),
		'desc' => __('Add font-awesome icon name for back to top', 'cleaning'),
		'id' => 'backtpicn',
		'std' => 'arrow-alt-circle-up',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Select color for back to top icon', 'cleaning'),
		'id' => 'backtpicnclr',
		'std' => '#25caf8',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select hover color for back to top icon', 'cleaning'),
		'id' => 'backtpicnhvclr',
		'std' => '#131313',
		'type' => 'color');	
	
	//excerpt length
	$options[] = array(		
		'name' => __('Excerpt Lenth', 'cleaning'),
		'desc' => __('Select excerpt length for testimonials section', 'cleaning'),
		'id' => 'testimonialsexcerptlength',
		'std' => '34',
		'type' => 'text');
			
	$options[] = array(				
		'desc' => __('Select excerpt length for Latest News Posts', 'cleaning'),
		'id' => 'latestnewslength',
		'std' => '32',
		'type' => 'text');	
	
	$options[] = array(									
		'desc' => __('Select excerpt length for blog page posts', 'cleaning'),
		'id' => 'blogpagepostexcerptlength',
		'std' => '26',
		'type' => 'text');
			
	$options[] = array(	
		'name' => __('Read More Text', 'cleaning'),		
		'desc' => __('Change read more button text for blog posts ', 'cleaning'),
		'id' => 'blogpostreadmoretext',
		'std' => 'Read More',
		'type' => 'text');								
		
	$options[] = array(
		'name' => __('Blog Single Layout', 'cleaning'),
		'desc' => __('Select layout. eg:Boxed, Wide', 'cleaning'),
		'id' => 'singlelayout',
		'type' => 'select',
		'std' => 'singleright',
		'options' => array('singleright'=>'Blog Single Right Sidebar', 'singleleft'=>'Blog Single Left Sidebar', 'sitefull'=>'Blog Single Full Width', 'nosidebar'=>'Blog Single No Sidebar') );	
		
	$options[] = array(
		'name' => __('Woocommerce Page Layout', 'cleaning'),
		'desc' => __('Select layout. eg:right-sidebar, left-sidebar, full-width', 'cleaning'),
		'id' => 'woocommercelayout',
		'type' => 'select',
		'std' => 'woocommercesitefull',
		'options' => array('woocommerceright'=>'Woocommerce Right Sidebar', 'woocommerceleft'=>'Woocommerce Left Sidebar', 'woocommercesitefull'=>'Woocommerce Full Width') );

	$options[] = array(
		'name' => __('Woocommerce Shop Page Image Hover Effect', 'cleaning'),
		'desc' => __('Turn ON/OFF image hover effect on shop page', 'cleaning'),
		'id' => 'imgeffect',
		'type' => 'select',
		'std' => 'off',
		'options' => array('on'=>'ON', 'off'=>'OFF') );
		
	//Layout Settings
	$options[] = array(
		'name' => __('Sections', 'cleaning'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('Number of Sections', 'cleaning'),
		'desc' => __('Select number of sections', 'cleaning'),
		'id' => 'numsection',
		'type' => 'select',
		'std' => '8',
		'options' => array_combine(range(1,30), range(1,30)) );

	$numsecs = of_get_option( 'numsection', 8 );

	for( $n=1; $n<=$numsecs; $n++){
		$options[] = array(
			'desc' => sprintf( __( '<h3>Section %s </h3>', 'cleaning' ), ''.$n.''),
			'class' => 'toggle_title',
			'type' => 'info');	
			
		$options[] = array(
			'name' => __('Section Container Class', 'cleaning'),
			'desc' => __('Add class "container" for normal width and "full-container" for full width', 'cleaning'),
			'id' => 'secclass'.$n,
			'std' => ( ( isset($section_text[$n]['section_class']) ) ? $section_text[$n]['section_class'] : '' ),
			'type' => 'text');
				
		$options[] = array(
			'name' => __('Animation Type', 'cleaning'),
			'id' => 'sectionanimate'.$n,			
			'type' => 'select',	
			'std' => 'fadeInUp',	
			'options'	=> array('none'=>'None','fadeInUp'=>'Fade In Up','bounce'=>'Bounce', 'bounceIn'=>'Bounce In','bounceInDown'=>'Bounce In Down','bounceInLeft'=>'Bounce In Left', 'bounceInRight'=>'Bounce In Right', 'bounceInUp'=>'Bounce In Up','fadeIn'=>'Fade In','fadeInDown'=>'Fade In Down','fadeInDownBig'=>'Fade In Down Big','fadeInLeft'=>'Fade In Left','fadeInLeftBig'=>'Fade In Left Big','fadeInRight'=>'Fade In Right','fadeInRightBig'=>'Fade In Right Big','fadeInUp'=>'Fade In Up','fadeInUpBig'=>'Fade In Up Big','flipInX'=>'Flip In X','flipInY'=>'Flip In Y','lightSpeedIn'=>'Light Speed In','slideInUp'=>'Slide In Up','slideInDown'=>'Slide In Down','slideInLeft'=>'Slide In Left','slideInRight'=>'Slide In Right','zoomIn'=>'Zoom In','zoomInDown'=>'Zoom In Down','zoomInLeft'=>'Zoom In Left','zoomInRight'=>'Zoom In Right','zoomInUp'=>'Zoom In Up'));

		$options[] = array(
			'name' => __('Section Sub Title', 'cleaning'),
			'id' => 'sectionsubtitle'.$n,
			'std' => ( ( isset($section_text[$n]['section_sub_title']) ) ? $section_text[$n]['section_sub_title'] : '' ),
			'type' => 'text');

		$options[] = array(
			'name' => __('Section Title', 'cleaning'),
			'id' => 'sectiontitle'.$n,
			'std' => ( ( isset($section_text[$n]['section_title']) ) ? $section_text[$n]['section_title'] : '' ),
			'type' => 'text');

		$options[] = array(
			'name' => __('Section Text', 'cleaning'),
			'id' => 'sectiontext'.$n,
			'std' => ( ( isset($section_text[$n]['section_text']) ) ? $section_text[$n]['section_text'] : '' ),
			'type' => 'text');

		$options[] = array(
			'name' => __('Section Background Color', 'cleaning'),
			'desc' => __('Select background color for section', 'cleaning'),
			'id' => 'sectionbgcolor'.$n,
			'std' => ( ( isset($section_text[$n]['bgcolor']) ) ? $section_text[$n]['bgcolor'] : '' ),
			'type' => 'color');
			
		$options[] = array(
			'name' => __('Background Image', 'cleaning'),
			'id' => 'sectionbgimage'.$n,
			'class' => '',
			'std' => ( ( isset($section_text[$n]['bgimage']) ) ? $section_text[$n]['bgimage'] : '' ),
			'type' => 'upload');

		$options[] = array(
			'name' => __('Section CSS Class', 'cleaning'),
			'desc' => __('Set class for this section.', 'cleaning'),
			'id' => 'sectionclass'.$n,
			'std' => ( ( isset($section_text[$n]['class']) ) ? $section_text[$n]['class'] : '' ),
			'type' => 'text');
			
		$options[] = array(
			'name'	=> __('Hide Section', 'cleaning'),
			'desc'	=> __('Check to hide this section', 'cleaning'),
			'id'	=> 'hidesec'.$n,
			'type'	=> 'checkbox',
			'std'	=> '');

		$options[] = array(
			'name' => __('Section Content', 'cleaning'),
			'id' => 'sectioncontent'.$n,
			'std' => ( ( isset($section_text[$n]['content']) ) ? $section_text[$n]['content'] : '' ),
			'type' => 'editor');
	}


	//SLIDER SETTINGS
	$options[] = array(
		'name' => __('Homepage Slider', 'cleaning'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('Inner Page Banner', 'cleaning'),
		'desc' => __('Upload inner page banner for site', 'cleaning'),
		'id' => 'innerpagebanner',
		'std'	=> get_template_directory_uri()."/images/inner-banner.jpg",
		'type' => 'upload');

	$options[] = array(			
		'desc'	=> __('Check To hide inner page banner ( NOTE : Change innerpage title color after hiding innerpage banner.)', 'cleaning'),
		'id'	=> 'hidepagebanner',
		'type'	=> 'checkbox',
		'std'	=> '');
	
	$options[] = array(
		'name' => __('Homepage Slider Show / Hide', 'cleaning'),
		'desc' => __('Show / Hide slider on Homepage(Note: Add Header Image in Customizer if you want to hide slider on Home Page.)', 'cleaning'),
		'id' => 'homepageslider',
		'type' => 'select',
		'std' => 'show',
		'options' => array('show'=>'Show', 'hide'=>'Hide') );
		
	$options[] = array(
		'name' => __('Inner Page Slider', 'cleaning'),
		'desc' => __('Show / Hide inner page slider', 'cleaning'),
		'id' => 'innerpageslider',
		'type' => 'select',
		'std' => 'hide',
		'options' => array('show'=>'Show', 'hide'=>'Hide') );
	
	$options[] = array(
		'name' => __('Slider Loader', 'cleaning'),
		'desc' => __('Upload slider loader here 100x100 ( Only gif image )', 'cleaning'),
		'id' => 'sliderloader',
		'std'	=> get_template_directory_uri()."/images/loading.gif",
		'type' => 'upload');
		
	$options[] = array(
		'name' => __('Slider Overlay Color', 'cleaning'),
		'desc' => __('Select color for slider overlay', 'cleaning'),
		'id' => 'sldbgcolor',
		'std' => '#000000',
		'type' => 'color');
	
	$options[] = array(
		'desc' => __('Select opacity for slider overlay','cleaning'),
		'id' => 'sldbgopac',
		'std' => '0.1',
		'type' => 'select',
		'options' => array('1'=>1, '0.9'=>0.9,'0.8'=>0.8,'0.7'=>0.7,'0.6'=>0.6,'0.5'=>0.5,'0.4'=>0.4,'0.3'=>0.3,'0.2'=>0.2,'0.1'=>0.1,'0'=>0,)
	);
	
	$options[] = array(
		'name' => __('Slider Overlay Text Position','cleaning'),
		'desc' => __('Select text position of slider overlay text','cleaning'),
		'id' => 'sldtxt',
		'std' => 'left',
		'type' => 'select',
		'options' => array('left'=>'Left', 'center'=>'Center','right'=>'Right')
	);
		
	$options[] = array(
		'name' => __('Custom Slider Shortcode Area For Home Page', 'cleaning'),
		'desc' => __('Enter here your slider shortcode without php tag', 'cleaning'),
		'id' => 'customslider',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Slider Effects and Timing', 'cleaning'),
		'desc' => __('Select slider effect.','cleaning'),
		'id' => 'slideefect',
		'std' => 'random',
		'type' => 'select',
		'options' => array('random'=>'Random', 'fade'=>'Fade', 'fold'=>'Fold', 'sliceDown'=>'Slide Down', 'sliceDownLeft'=>'Slide Down Left', 'sliceUp'=>'Slice Up', 'sliceUpLeft'=>'Slice Up Left', 'sliceUpDown'=>'Slice Up Down', 'sliceUpDownLeft'=>'Slice Up Down Left', 'slideInRight'=>'SlideIn Right', 'slideInLeft'=>'SlideIn Left', 'boxRandom'=>'Box Random', 'boxRain'=>'Box Rain', 'boxRainReverse'=>'Box Rain Reverse', 'boxRainGrow'=>'Box Rain Grow', 'boxRainGrowReverse'=>'Box Rain Grow Reverse' ));
	
	$options[] = array(
		'desc' => __('ON / OFF autoplay slider','cleaning'),
		'id' => 'onoffauto',
		'std' => 'false',
		'type' => 'select',
		'options' => array('false'=>'ON', 'true'=>'Off'));
		
	$options[] = array(
		'desc' => __('Animation speed should be multiple of 100.', 'cleaning'),
		'id' => 'slideanim',
		'std' => 500,
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add slide pause time.', 'cleaning'),
		'id' => 'slidepause',
		'std' => 4000,
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slide Controllers', 'cleaning'),
		'desc' => __('Hide/Show Direction Naviagtion of slider.','cleaning'),
		'id' => 'slidenav',
		'std' => 'true',
		'type' => 'select',
		'options' => array('true'=>'Show', 'false'=>'Hide'));
		
	$options[] = array(
		'desc' => __('Hide/Show pager of slider.','cleaning'),
		'id' => 'slidepage',
		'std' => 'false',
		'type' => 'select',
		'options' => array('true'=>'Show', 'false'=>'Hide'));
		
	$options[] = array(
		'desc' => __('Pause Slide on Hover.','cleaning'),
		'id' => 'slidepausehover',
		'std' => 'false',
		'type' => 'select',
		'options' => array('true'=>'Yes', 'false'=>'No'));
		
	$options[] = array(
		'name' => __('Slider Image 1 (1520x686)', 'cleaning'),
		'desc' => __('First Slide', 'cleaning'),
		'id' => 'slide1',
		'std' => get_template_directory_uri()."/images/slides/slider1.jpg",
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle1',
		'std' => 'We keep Your World Fresh &amp; Sparkling Clean',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes1',
		'std' => 'Donec pretium, neque vel lobortis congue, mi eros faucibus purus, eu hendrerit diam sem non sapien. Nam eleifend orci massa. Aenean consectetur pulvinar metus quis blandit. Maecenas aliquam ultrices dapibus. Aenean in quam quis metus pellentesque blandit at in nulla. Etiam tempus iaculis justo, vitae sagittis tellus placerat eget.',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton1',
		'std' => 'How we do it',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl1',
		'std' => '#',
		'type' => 'text');												
	
	$options[] = array(
		'name' => __('Slider Image 2 (1520x686)', 'cleaning'),
		'desc' => __('Second Slide', 'cleaning'),
		'id' => 'slide2',
		'std' => get_template_directory_uri()."/images/slides/slider2.jpg",
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle2',
		'std' => 'Get the kind of clean that only comes from a team of specialists.',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes2',
		'std' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae est at dolor auctor faucibus. Aenean hendrerit lorem eget nisi vulputate, vitae fringilla ligula dignissim. Phasellus feugiat quam efficitur Lorem ipsum dolor sit amet.',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton2',
		'std' => 'Read More',
		'type' => 'text');

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl2',
		'std' => '#',
		'type' => 'text');	
	
	$options[] = array(
		'name' => __('Slider Image 3 (1520x686)', 'cleaning'),
		'desc' => __('Third Slide', 'cleaning'),
		'id' => 'slide3',
		'std' => get_template_directory_uri()."/images/slides/slider3.jpg",
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle3',
		'std' => 'Professional quality cleaning with a personal touch.',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes3',
		'std' => 'Donec pretium, neque vel lobortis congue, mi eros faucibus purus, eu hendrerit diam sem non sapien. Nam eleifend orci massa. Aenean consectetur pulvinar metus quis blandit. Maecenas aliquam ultrices dapibus. Aenean in quam quis metus pellentesque blandit at in nulla. Etiam tempus iaculis justo, vitae sagittis tellus placerat eget.',
		'type' => 'text');	
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton3',
		'std' => 'View More',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl3',
		'std' => '#',
		'type' => 'text');
	
	$options[] = array(
		'name' => __('Slider Image 4 (1520x686)', 'cleaning'),
		'desc' => __('Third Slide', 'cleaning'),
		'id' => 'slide4',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle4',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes4',
		'std' => '',
		'type' => 'text');	
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton4',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl4',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'name' => __('Slider Image 5 (1520x686)', 'cleaning'),
		'desc' => __('Fifth Slide', 'cleaning'),
		'id' => 'slide5',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle5',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes5',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton5',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl5',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 6 (1520x686)', 'cleaning'),
		'desc' => __('Sixth Slide', 'cleaning'),
		'id' => 'slide6',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle6',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes6',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton6',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl6',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 7 (1520x686)', 'cleaning'),
		'desc' => __('Seventh Slide', 'cleaning'),
		'id' => 'slide7',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle7',
		'std' => '',
		'type' => 'text');

	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes7',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton7',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl7',
		'std' => '',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('Slider Image 8 (1520x686)', 'cleaning'),
		'desc' => __('Eighth Slide', 'cleaning'),
		'id' => 'slide8',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle8',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes8',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton8',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl8',
		'std' => '',
		'type' => 'text');

	$options[] = array(
		'name' => __('Slider Image 9 (1520x686)', 'cleaning'),
		'desc' => __('Ninth Slide', 'cleaning'),
		'id' => 'slide9',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle9',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes9',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton9',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl9',
		'std' => '',
		'type' => 'text');
			
	$options[] = array(
		'name' => __('Slider Image 10 (1520x686)', 'cleaning'),
		'desc' => __('Tenth Slide', 'cleaning'),
		'id' => 'slide10',
		'std' => '',
		'type' => 'upload');

	$options[] = array(
		'desc' => __('Slide Main Title', 'cleaning'),
		'id' => 'slidetitle10',
		'std' => '',
		'type' => 'text');
	
	$options[] = array(
		'desc' => __('Slide Description', 'cleaning'),
		'id' => 'slidedes10',
		'std' => '',
		'type' => 'text');	
	
	$options[] = array(
		'desc' => __('Enter text for button one', 'cleaning'),
		'id' => 'slidebutton10',
		'std' => '',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Enter url for button one', 'cleaning'),
		'id' => 'slideurl10',
		'std' => '',
		'type' => 'text');
	
	//FOOTER SETTINGS
	$options[] = array(
		'name' => __('Footer', 'cleaning'),
		'type' => 'heading');
	
	$options[] = array(
		'name' => __('Footer Column', 'cleaning'),
		'desc' => __('Select Footer Columns from here', 'cleaning'),
		'id' => 'footcols',
		'type' => 'select',
		'std' => 'foocolsthree',
		'options' => array('foocolstwo'=>'Footer Two Columns', 'foocolsthree'=>'Footer Three Columns', 'foocolsfour'=>'Footer Four Columns') );
		
	$options[] = array(
		'name' => __('Footer Copyright Text', 'cleaning'),
		'desc' => __('Copyright Text for your site.', 'cleaning'),
		'id' => 'copyrighttext',
		'std' => '&copy; Copyright 2020. All Rights Reserved.',
		'type' => 'textarea');

	$options[] = array(
		'name' => __('Footer Design by Text', 'cleaning'),
		'desc' => __('Design by Text for your site.', 'cleaning'),
		'id' => 'designbytext',
		'std' => 'Theme Designed by <a href="'.esc_url('http://www.flythemes.net/').'" target="_blank">Fly Themes</a>.',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Footer Back to Top Button', 'cleaning'),
		'id' => 'backtotop',
		'std' => '[back-to-top]',
		'type' => 'textarea',);
		
	//CONTACT US
	$options[] = array(
		'name' => __('Contact Page', 'cleaning'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('Contact Infromation', 'cleaning'),
		'desc' => __('Add heading here', 'cleaning'),
		'id' => 'contheading',
		'std' => '[custom_heading title="Contact Us" title_color="#1c1f26" font_size="35px" font_family="Montserrat" align="left"]',
		'type' => 'textarea');

	$options[] = array(
		'desc' => __('Add Contact page information here.', 'cleaning'),
		'id' => 'contactinfo',
		'std' => 'Praesent mollis non lorem at interdum. Cum sociis natoque penatibus et magnis dis parturient, tempus risus at, tempor enim.',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Add Address here', 'cleaning'),
		'id' => 'contadd',
		'std' => 'Saint Patrick Hall Garden street, California',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add Phone Number here', 'cleaning'),
		'id' => 'contphone',
		'std' => '+(01) 600 417 2100',
		'type' => 'text');

	$options[] = array(
		'desc' => __('Add Fax Number here', 'cleaning'),
		'id' => 'contfax',
		'std' => '+91 8888-552-8462',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add Email here', 'cleaning'),
		'id' => 'contmail',
		'std' => '<a href="mailto:info@sitename.com">info@sitename.com</a>',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Google Map', 'cleaning'),
		'desc' => __('Use iframe code url here. DO NOT APPLY IFRAME TAG', 'cleaning'),
		'id' => 'googlemap',
		'std' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9934.13833244108!2d-0.12172020634120727!3d51.5034077741501!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487604b84cdc0031%3A0x261185c6bcdaf4b2!2sWaterloo%2C%20London%2C%20UK!5e0!3m2!1sen!2sin!4v1583483040572!5m2!1sen!2sin',
		'type' => 'textarea');

	//Short codes						
	$options[] = array(
		'name' => __('Short Codes', 'cleaning'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('introduction Box', 'cleaning'),
		'desc' => __('[introduction image="http://flythemesdemo.net/cleaning/wp-content/themes/cleaning-pro/images/intro.jpg" image_position="left/right" title="High Quality & Best Cleaning Services" sub_title="A Trusted Cleaning Company" button_text="Read More" link="#"] Your content goes here... [/introduction]', 'cleaning'),
		'type' => 'info' );

	$options[] = array(
		'name' => __('Icon Box', 'cleaning'),
		'desc' => __('[icon_box icon="leaf" icon_style="solid" title="Green Cleaning Solution" link="#"] Short content goes here... [/icon_box]', 'cleaning'),
		'type' => 'info' );

	$options[] = array(
		'name' => __('Image Box', 'cleaning'),
		'desc' => __('[image_box image="http://flythemesdemo.net/cleaning/wp-content/themes/cleaning-pro/images/service-1.jpg" title="Window Cleaning" button_text="View Service" link="#"] Short content goes here...  [/image_box]', 'cleaning'),
		'type' => 'info' );

	$options[] = array(
		'name' => __('Information Box', 'cleaning'),
		'desc' => __('[info_box icon="usd-circle" icon_style="light" title="Affordable Price" link="#"] Short content goes here... [/info_box]', 'cleaning'),
		'type' => 'info' );
	
	$options[] = array(
		'name' => __('Pop Up Video', 'cleaning'),
		'desc' => __('[popup_video video_link="Add youtube/vimeo video url here"]', 'cleaning'),
		'type' => 'info' );

	$options[] = array(
		'name' => __('Pricing Box', 'cleaning'),
		'desc' => __('[pricing-plan title="Add title here" price="30" price_sign="$" duration="Yr" highlight="yes/no" row1="Add content here" row2="Add content here" row3="Add content here" row4="Add content here" row5="Add content here" row6="Add content here" row7="Add content here" row8="Add content here" row9="Add content here" row10="Add content here" btn_label="Purchase Now" link="#"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Section Title', 'cleaning'),
		'desc' => __('[section_title sub_title="Add sub title here" title="Add Section Title" section_text="Add Section text here"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Custom Heading', 'cleaning'),
		'desc' => __('[custom_heading sml_ttl="Add small title here" sml_title_color="#fb6eb5" title="Custom Heading" title_color="#00aeef" font_size="36px" font_family="Roboto" align="left/center/right"]', 'cleaning'),
		'type' => 'info'
	);
		
	$options[] = array(
		'name' => __('Photo Gallery Grid Layout', 'cleaning'),
		'desc' => __('[photo-gallery show="-1" type="grid" column="2/3/4"]<br><strong>You can also display a gallery of a particular category by adding (category="add category slug") option in shortcode.</strong>', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Photo Gallery Slider Layout', 'cleaning'),
		'desc' => __('[photo-gallery show="-1" type="slider"]', 'cleaning'),
		'type' => 'info'
	);

	$options[] = array(
		'name' => __('Photo Gallery Filter Layout', 'cleaning'),
		'desc' => __('[photo-gallery show="-1" type="filter"]', 'cleaning'),
		'type' => 'info'
	);
		
	$options[] = array(
		'name' => __('Latest News/Blog Grid Layout', 'cleaning'),
		'desc' => __('[latest-news show="3" type="grid" column="2/3/4" from_category="Add category slug" comment="show/hide" date="show/hide" author="show/hide" category="show/hide"]', 'cleaning'),
		'type' => 'info'
	);
	$options[] = array(
		'name' => __('Latest News/Blog Slider Layout', 'cleaning'),
		'desc' => __('[latest-news show="-1" type="slider" from_category="Add category slug" comment="show/hide" date="show/hide" author="show/hide" category="show/hide"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Testimonials Rotator', 'cleaning'),
		'desc' => __('[testimonials show="4"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Testimonials Listing', 'cleaning'),
		'desc' => __('[testimonials-listing show="3"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Testimonials Sidebar Rotator', 'cleaning'),
		'desc' => __('[sidebar-testimonials show="2"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Team Members Grid Layout', 'cleaning'),
		'desc' => __('[our-team type="grid" show="-1" column="2/3/4"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Team Members Slider Layout', 'cleaning'),
		'desc' => __('[our-team type="slider" show="-1"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Portfolio Grid Type', 'cleaning'),
		'desc' => __('[portfolio show="no. of item to be shown( Note: -1 for displaying all items )" type="filter" filter="true/false" column="2/3/4"]', 'cleaning'),
		'type' => 'info'
	);

	$options[] = array(
		'name' => __('Portfolio Slider Type', 'cleaning'),
		'desc' => __('[portfolio show="no. of item to be shown( Note: -1 for displaying all items )" type="slider"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Image Carousel/Portfolio Gallery', 'cleaning'),
		'desc' => __('[image_carousel][image path="Add image path here"][image path="Add image path here"][/image_carousel]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Client Logo Rotator', 'cleaning'),
		'desc' => __('[client_lists][client image="Add image path here" link="#"][client image="Add image path here" link="#"][client image="Add image path here" link="#"][/client_lists]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Counter', 'cleaning'),
		'desc' => __('[counter_wrap][counter title="Projects Finished" count="600" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Satisfied Customers" count="1450" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Branches Network" count="60" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Cleaning Tips" count="3000" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][counter title="Free Quotes Sent" count="900" plus="yes" bg_color="#27c9f7" number_color="#ffffff" title_color="#ffffff"][/counter_wrap]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Social Icons', 'cleaning'),
		'desc' => __('[social_area][social icon="facebook" link="#"][social icon="instagram" link="#"][social icon="twitter" link="#"][/social_area]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Section ( NOTE : This shortcode will only work with "full-screen" page template )', 'cleaning'),
		'desc' => __('[section container_class="container/full-container" animation_type="fadeIn" background_image="Add background image path" background_color="#ffffff" section_sub_title="Add section sub title" section_title="Add section title" section_text="Add sub text here" section_class="Add class to this section"] Add content / shortcode here [/section]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Two Columns', 'cleaning'),
		'desc' => __('[column_content type="one_half" subcls="Add extra class"] Add Content here [/column_content][column_content type="one_half_last" subcls="Add extra class"] Add Content here [/column_content]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Three Columns', 'cleaning'),
		'desc' => __('[column_content type="one_third" subcls="Add extra class"][/column_content][column_content type="one_third" subcls="Add extra class"][/column_content] [column_content type="one_third_last" subcls="Add extra class"][/column_content]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Four Columns', 'cleaning'),
		'desc' => __('[column_content type="one_fourth" subcls="Add extra class"][/column_content][column_content type="one_fourth" subcls="Add extra class"][/column_content][column_content type="one_fourth" subcls="Add extra class"][/column_content][column_content type="one_fourth_last" subcls="Add extra class"][/column_content]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Five Columns', 'cleaning'),
		'desc' => __('[column_content type="one_fifth" subcls="Add extra class"][/column_content][column_content type="one_fifth" subcls="Add extra class"][/column_content][column_content type="one_fifth" subcls="Add extra class"][/column_content][column_content type="one_fifth" subcls="Add extra class"][/column_content][column_content type="one_fifth_last" subcls="Add extra class"][/column_content]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Accordion', 'cleaning'),
		'desc' => __('[accordion][accordion_content title="Add title here"] Short content here [/accordion_content][accordion_content title="Add title here"] Short content here [/accordion_content][/accordion]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Tabs', 'cleaning'),
		'desc' => __('[tabs][tab title="Tab Title 1"] Content goes here [/tab][tab title="Tab Title 2"] Content goes here [/tab][/tabs]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Toogle', 'cleaning'),
		'desc' => __('[toggle_content title="Add Toggle"] Content goes here [/toggle_content][toggle_content title="Add Toggle"] Content goes here [/toggle_content]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Skill Bar', 'cleaning'),
		'desc' => __('[skill title="Wordpress" percent="94"][skill title="SEO" percent="98"][skill title="HTML" percent="92"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Unorderd List', 'cleaning'),
		'desc' => __('[unordered_list style="list-1/list-2/list-3/list-4/list-5/list-6/list-7/list-8/list-9/list-10"]&lt;li&gt;Add content&lt;/li&gt; &lt;li&gt;Add content&lt;/li&gt; &lt;li&gt;Add content&lt;/li&gt;[/unordered_list]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Blockquote', 'cleaning'),
		'desc' => __('[blockquote align="left/right"] Phasellus suscipit porttitor fringilla. Vivamus eu placerat elit. Quisque sem. Integer vehicula tristique efficitur. Phasellus suscipit porttitor fringilla. Vivamus eu placerat elit. Quisque sem [/blockquote]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Youtube Video', 'cleaning'),
		'desc' => __('[youtube vid_identifier="_mlf-lP9g6E"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Vimeo Video', 'cleaning'),
		'desc' => __('[vimeo vid_identifier="144785540"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Dropcap', 'cleaning'),
		'desc' => __('[dropcap]L[/dropcap]orem integer vehicula tristique efficitur. Phasellus suscipit porttitor fringilla. Vivamus eu placerat elit. Quisque sem. Integer vehicula tristique efficitur. Phasellus suscipit porttitor fringilla. Vivamus eu placerat elit. Quisque sem.', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Messages : Success Message', 'cleaning'),
		'desc' => __('[message type="success"]This is a sample of the "success" style message box shortcode. To use this style use the following shortcode[/message]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Error Message', 'cleaning'),
		'desc' => __('[message type="error"]This is a sample of the "error" style message box shortcode. To use this style use the following shortcode.[/message]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Warning Message', 'cleaning'),
		'desc' => __('[message type="warning"]This is a sample of the "warning" style message box shortcode. To use this style use the following shortcode.[/message]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Information Message', 'cleaning'),
		'desc' => __('[message type="info"]This is a sample of the "info" style message box shortcode. To use this style use the following shortcode.[/message]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('About Message', 'cleaning'),
		'desc' => __('[message type="about"]This is a sample of the "about" style message box shortcode. To use this style use the following shortcode.[/message]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Button Style One', 'cleaning'),
		'desc' => __('[button name="Button" align="left/center/right" link="#"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Button Style Two', 'cleaning'),
		'desc' => __('[buttonstyle2 name="Button" align="left/center/right" link="#"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Gradient Button', 'cleaning'),
		'desc' => __('[gradient_button size="small/medium/large/x-large" bg_color="#fb6eb5" color="#ffffff" text="Gradient Button" title="Gradient Button" url="Add link here" position="left/right"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Simple Button', 'cleaning'),
		'desc' => __('[simple_button size="small/medium/large/x-large" bg_color="#00adef" color="#ffffff" text="Simple Button" title="Simple Button" url="Add link here" position="left/right"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Round Button', 'cleaning'),
		'desc' => __('[round_button style="light/dark" text="Round Button" title="Round Button" url="Add link here" position="left/right"]', 'cleaning'),
		'type' => 'info'
	);
	
	$options[] = array(
		'name' => __('Miscellaneous', 'cleaning'),
		'desc' => __('[clear]<br>[hr]<br>[back-to-top]<br>[searchform]<br>[spacer space="50"]', 'cleaning'),
		'type' => 'info'
	);
	
	return $options;
}