<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Cleaning
 */
?>
<div id="sidebar" <?php if( is_page_template('blog-post-left-sidebar.php')){?> style="float:left;"<?php } ?>>
    <?php dynamic_sidebar('sidebar-1'); ?>	
</div><!-- sidebar -->