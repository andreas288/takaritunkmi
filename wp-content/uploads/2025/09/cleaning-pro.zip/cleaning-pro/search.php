<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package Cleaning
 */

get_header(); ?>

<div class="container content-area">
    <div class="middle-align content_sidebar">
        <div class="site-main sitefull" id="sitemain">
			<?php if ( have_posts() ) : ?>
            	<div class="search-result-form">
                	<?php echo get_search_form(); ?>
                </div><!-- Search Result Form -->
                <?php while ( have_posts() ) : the_post(); ?>
                	<div class="search-result-box">
                    	<?php get_template_part( 'content', 'search' ); ?>
                    </div>
                <?php endwhile; cleaning_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'no-results', 'search' ); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>