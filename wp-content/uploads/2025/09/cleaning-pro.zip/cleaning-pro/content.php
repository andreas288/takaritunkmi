<?php
/**
 * @package Cleaning
 */

if ( has_post_thumbnail()) {
	$large_imgSrc = wp_get_attachment_image_src( get_post_thumbnail_id(), 'latest_post_thumb');
	$imgUrl = $large_imgSrc[0];
}else{
	$imgUrl = get_template_directory_uri().'/images/img_404.png';
}

$num_comments = get_comments_number(); // get_comments_number returns only a numeric value

if ( comments_open() ) {
	if ( $num_comments == 0 ) {
		$comments = __('No Comments','cleaning');
	} elseif ( $num_comments > 1 ) {
		$comments = $num_comments . __(' Comments','cleaning');
	} else {
		$comments = __('1 Comment','cleaning');
	}
	$write_comments = '<a href="' . get_comments_link() .'">'. $comments.'</a>';
} else {
	$write_comments =  __('Comments are off for this post.','cleaning');
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if( !is_search() ) : ?>
    	<div class="post-thumb" style="background-image:url('<?php echo $imgUrl; ?>');">
        	<div class="post-date"><?php echo get_the_date('d'); ?><span><?php echo get_the_date('M'); ?></span></div>
        	<figure class="post-thumb-wrap"><a href="<?php the_permalink(); ?>"></a></figure>
        </div><!-- post-thumb --> 
	<?php endif; ?>
    <div class="post-data">
    	<header class="entry-header">
        	<div class="entry-contains">
                <h3 class="post-title<?php if( is_search() ):?> search-title<?php endif; ?>"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
                <?php if( !is_search() ): ?>
                    <ul class="post-meta">
                        <span class="post-auth"><?php echo get_the_author_posts_link(); ?></span>
                        <span class="post-cate"><?php echo getPostCategories(); ?></span>
                        <span class="post-comnt"><?php echo $write_comments; ?></span>
                    </ul>
                <?php endif; ?>
            </div>
        </header>
        <?php if ( is_search() ) : // Only display Excerpts for Search ?>
        	<div class="entry-summary">            	
                <p><?php the_excerpt( ); ?></p>
                <?php
                    wp_link_pages( array(
                        'before' => '<div class="page-links">' . __( 'Pages:', 'cleaning' ),
                        'after'  => '</div>',
                    ) );
                ?>
                <a href="<?php the_permalink(); ?>" class="ln-read-more"><span><?php echo of_get_option('blogpostreadmoretext'); ?></span></a>
            </div><!-- .entry-summary -->
        <?php else : ?>
        	<div class="entry-content">            	
				<p><?php echo content( of_get_option('blogpagepostexcerptlength') ); ?></p>
                <a href="<?php the_permalink(); ?>" class="ln-read-more"><span><?php echo of_get_option('blogpostreadmoretext'); ?></span></a>
            </div><!-- .entry-content -->
        <?php endif; ?>
    </div><!-- post data -->
    
</article><!-- article -->