<?php
/**
 * Template name: Contact Us

 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package cleaning Pro
 */

get_header(); ?>
<?php if( of_get_option('googlemap',true ) != '' ){ ?>
    <div class="gmap">
        <iframe class="blackmap" src="<?php echo of_get_option('googlemap', true); ?>" width=98% height=400 frameborder=0></iframe>
    </div>
<?php } ?>
<div class="content-area">
    <div class="middle-align">
        <div class="site-main sitefull">
            <div class="contact-content">
                <div class="flex-element">

                    <div class="contact-page-content">
                        <div class="inner-contact-page-content">
                            <?php while ( have_posts() ) : the_post(); ?>
                                <?php the_content(); ?>             
                            <?php endwhile; // end of the loop. ?>
                        </div>
                    </div><!-- contact-page-map -->

                    <div class="contact-page-info">
                        <div class="inner-contact-page-info">
                            <?php 
                                if( of_get_option('contheading') != ''){
                                    echo do_shortcode( of_get_option('contheading'));
                                } if( of_get_option('contactinfo',true) ) {
                                    echo '<p>'.of_get_option('contactinfo', true ).'</p>'; 
                            } ?>
                            <ul>
                                <li class="icon-address"><span><?php echo __('Address','cleaning'); ?>: </span><?php echo of_get_option( 'contadd',true ); ?></li>
                                <li class="icon-phone"><span><?php echo __('Phone','cleaning'); ?>: </span><?php echo of_get_option( 'contphone',true ); ?></li>
                                <li class="icon-fax"><span><?php echo __('Fax','cleaning'); ?>: </span><?php echo of_get_option( 'contfax',true ); ?></li>
                                <li class="icon-email"><span><?php echo __('Email','cleaning'); ?>: </span><?php echo of_get_option( 'contmail',true ); ?></li>
                            </ul>
                        </div>
                    </div><!-- contact-page-info text-center --><div class="clear"></div>

                </div><!-- flex element -->
            </div><!-- contact content -->
        </div><!-- site-main -->
    </div><!-- middle align -->
</div><!-- content-area -->
<?php get_footer(); ?>