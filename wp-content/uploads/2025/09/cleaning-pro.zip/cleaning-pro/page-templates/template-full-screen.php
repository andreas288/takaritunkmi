<?php
/**
 * Template name: Full Screen

 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Cleaning Pro
 */

get_header(); ?>

<div class="content-area no-padding">
    <div class="middle-align">
        <div class="site-main sitefull">
			<?php while ( have_posts() ) : the_post(); get_template_part( 'content', 'page' ); endwhile; // end of the loop. ?>
        </div>
        <div class="clear"></div>
    </div>
</div>

<?php get_footer(); ?>