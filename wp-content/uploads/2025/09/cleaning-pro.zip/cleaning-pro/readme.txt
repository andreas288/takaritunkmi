/*-----------------------------------------------------------------------------------*/
/* Cleaning WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Cleaning 
Theme URI       :   https://flythemes.net/wordpress-themes/cleaning-wordpress-theme/
Version         :   Pro 1.0
Tested up to    :   WP 5.4.2 and above
Author          :   FlyThemes
Author URI      :   https://www.flythemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@flythemes.net

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- Nivoslider is licensed under MIT License.
- html5.js is dual licensed under MIT and GPL2.

2 - Fonts used in this theme are defined below

	Montserrat :https://www.google.com/fonts/specimen/Montserrat
	License: Distributed under the terms of the Apache License, version 2.0 		
	http://www.apache.org/licenses/LICENSE-2.0.html

3 - Images used from Pxhere.
	Pxhere provides images under CC0 license 
	(https://creativecommons.org/about/cc0)	
	
	Home Page Slider
	----------------
	https://pxhere.com/en/photo/1175878
	https://pixabay.com/en/sport-fitness-woman-training-2260736/
	https://pxhere.com/en/photo/929409

For any help you can mail us at support[at]flythemes.net