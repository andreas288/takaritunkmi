<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package Cleaning
 */

get_header(); ?>

<div class="container content-area">
    <div class="middle-align">
        <div class="error-404 not-found sitefull text-center">
            <header class="page-header">
                <h1 class="title-404"><?php _e( '404', 'cleaning' ); ?></h1>
                <span class="sub-title-404"><?php _e( 'This page is not found', 'cleaning' ); ?></span>
            </header><!-- .page-header -->
            <div class="page-content">
                <p class="text-404"><?php _e( 'Sorry but the page you are looking for doesn&acute;t exist.', 'cleaning' ); ?></p>
                <?php get_search_form(); ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="404-return"><?php _e('< Back To Home','cleaning'); ?></a>
            </div><!-- .page-content -->
        </div>
        <div class="clear"></div>
    </div>
</div>

<?php get_footer(); ?>