<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Cleaning Pro
 */
get_header(); ?>

<div class="container content-area">
    <div class="middle-align sidebar_content">
        <div class="site-main flotRight" id="sitemain">
            <?php
                while ( have_posts() ) : the_post();
                $portgal = esc_html( get_post_meta( get_the_ID(), '_portfgal', true ) );

                $portdatelbl = esc_html( get_post_meta( get_the_ID(), '_pdatelbl', true ));
                $portdate = esc_html( get_post_meta( get_the_ID(), '_pdate', true ) );

                $portclientlbl = esc_html( get_post_meta( get_the_ID(), '_pclientlbl', true ) );
                $portclient = esc_html( get_post_meta( get_the_ID(), '_pclient', true ) );

                $portlocationlbl = esc_html( get_post_meta( get_the_ID(), '_plocationlbl', true ) );
                $portlocation = esc_html( get_post_meta( get_the_ID(), '_plocation', true ) );

                $portvaluelbl = esc_html( get_post_meta( get_the_ID(), '_pvaluelbl', true ) );
                $portvalue = esc_html( get_post_meta( get_the_ID(), '_pvalue', true ) );

                $portarchtlbl = esc_html( get_post_meta( get_the_ID(), '_parchtlbl', true ) );
                $portarcht = esc_html( get_post_meta( get_the_ID(), '_parcht', true ) );
            ?>
               
                <article class="portfolio-single">

                    <div class="portfolio-content">
                        <?php the_content(); ?>
                    </div><!-- portfolio-content -->
                    <div class="image-carousel">
                        <?php echo do_shortcode(''.$portgal.''); ?>
                    </div><!-- image-carousel -->
                    <div class="portfolio-share">
                        <?php echo cleaning_social_sharing_buttons(); ?>
                    </div><!-- portfolio-share -->

                </article><!-- portfolio-single -->
                <?php
                // Posts pagination
                cleaning_content_nav( 'nav-below' );
                
                // If comments are open or we have at least one comment, load up the comment template
                if ( comments_open() || '0' != get_comments_number() )
                    comments_template();
                ?> 

            <?php endwhile; // end of the loop. ?>
        </div>
        <div id="sidebar" style="float:left;">
            <div class="portfolio-metadeta">
                <h2><?php _e('Project Details','cleaning');?></h2>
                <?php if(!($portdate == null || $portdate == '')){ ?>
                    <div class="portfolio-metadata-item">
                        <span><strong><?php echo $portdatelbl; ?> : </strong></span><?php echo $portdate; ?>
                    </div>
                <?php } if(!($portclient == null || $portclient == '')){ ?>
                    <div class="portfolio-metadata-item">
                        <span><strong><?php echo $portclientlbl; ?> : </strong></span><?php echo $portclient; ?>
                    </div>
                <?php } if(!($portlocation == null || $portlocation == '')){ ?>
                    <div class="portfolio-metadata-item">
                        <span><strong><?php echo $portlocationlbl; ?> : </strong></span><?php echo $portlocation; ?>
                    </div>
                <?php } if(!($portvalue == null || $portvalue == '')){ ?>
                    <div class="portfolio-metadata-item">
                        <span><strong><?php echo $portvaluelbl; ?> : </strong></span><?php echo $portvalue; ?>
                    </div>
                <?php } if(!($portarcht == null || $portarcht == '')){ ?>
                    <div class="portfolio-metadata-item">
                        <span><strong><?php echo $portarchtlbl; ?> : </strong></span><?php echo $portarcht; ?>
                    </div>
                <?php } ?>
            </div><!-- metadeta-->
        </div> <div class="clear"></div>
    </div>
</div>
<?php get_footer(); ?>