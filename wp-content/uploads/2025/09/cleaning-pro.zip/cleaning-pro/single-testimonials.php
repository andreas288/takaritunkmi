<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Cleaning
 */
get_header(); ?>

<div class="container content-area">
    <div class="middle-align">
    	<?php
        	while ( have_posts() ) : the_post();
			$shwcdetails = esc_html( get_post_meta( get_the_ID(), 'cdetails', true ) );
		?>
    	<div id="sidebar" class="testi-sidebar">
        	<div class="single-testi-thumb">
            	<?php the_post_thumbnail('full' ); ?>
            </div><!-- single team thumb -->
            <div class="single-testi-info">
            	<h2><?php the_title(); ?></h2>
                <span><?php echo $shwcdetails; ?></span>
            </div><!-- single team info -->
        </div>
        <div class="site-main" id="sitemain">
        	<div class="single-testi-content">
        		<?php the_content();?>
            </div>
        </div><div class="clear"></div>
        <?php endwhile; // end of the loop. ?>
    </div>
</div>
<?php get_footer(); ?>