<?php
// Latest News Shortcode function
function cleaning_latest_news_func( $atts ){
	extract( shortcode_atts( array(
		'show' => '',
		'type' => '',
		'column' => '',
		'from_category' => '',		
		'comment' => '',
		'date' => '',
		'author' => '',
		'category' => '',
	),$atts));
	$postoutput = '';
	
	$postoutput .='<div class="latest-news-wrap">';
		
		$latest_post_query = new WP_Query(
			array(
				'posts_per_page'=>$show,
				'category_name' => $from_category,
				'post__not_in' => get_option('sticky_posts')
			)
		);		
		
		if ( $latest_post_query->have_posts() ) : $counter = 0; 
		
			if( $type == 'slider' ) :  $postoutput .='<div class="latestpost owl-carousel owl-theme">'; endif; 
			
			while ( $latest_post_query->have_posts() ) : $latest_post_query->the_post(); $counter++;
			
				$num_comments = get_comments_number(); // get_comments_number returns only a numeric value
	
				if ( comments_open() ) {
					if ( $num_comments == 0 ) {
						$comments = __('No Comments','cleaning');
					} elseif ( $num_comments > 1 ) {
						$comments = $num_comments . __(' Comments','cleaning');
					} else {
						$comments = __('1 Comment','cleaning');
					}
					$write_comments = '<a href="' . get_comments_link() .'">'. $comments.'</a>';
				} else {
					$write_comments =  __('Comments are off for this post.','cleaning');
				}
	
				if($comment=='show'){   
					$post_comment = '<span class="post-comnt">'.$write_comments.'</span>';
				} else {
					$post_comment = '';
				}			
				if($date=='show'){   
					$post_date = '<div class="post-date">'.get_the_date('d') .'<span>' . get_the_date('M') .'</span></div>';
				} else {
					$post_date = '';
				}	
				if($author=='show'){   
					$post_author = '<span class="post-auth">'.__('Written By ','cleaning').''.get_the_author_posts_link().'</span>';
				} else {
					$post_author = '';
				}			
				if($category=='show'){   
					$post_category = '<span class="post-cate">'.__('In ','cleaning').''.getPostCategories().'</span>';
				} else {
					$post_category = '';
				}
			
				$imgSrc = wp_get_attachment_image_src( get_post_thumbnail_id(), 'latest-news-thumb');			
			
				if ( $imgSrc[0]!='' ) {
					$imgUrl = $imgSrc[0];
				}else{
					$imgUrl = get_template_directory_uri().'/images/img_404.png';
				}
				
				if( $counter%2 == 0 ) $nomargn2 = ' lastcols'; else $nomargn2 = '';
				if( $counter%3 == 0 ) $nomargn3 = ' lastcols'; else $nomargn3 = '';
				if( $counter%4 == 0 ) $nomargn4 = ' lastcols'; else $nomargn4 = '';
				
				if( $column == 2 ) 
					$shwgridcol = 'grid-col-two '.$nomargn2.'';
				elseif( $column == 3 )
					$shwgridcol = 'grid-col-three '.$nomargn3.'';
				elseif( $column == 4 )	
					$shwgridcol = 'grid-col-four '.$nomargn4.'';

				if( $comment=='show' || $category=='show' || $author=='show' || $date=='show' ){
					$shwmeta = '<div class="post-meta">'.$post_author.' '.$post_category.' '.$post_comment.'</div>';
				}
				
				if( $type == 'grid' ) :
					$postoutput .= '<div class="news-box '.$shwgridcol.'">
						<div class="news-thumb">
							<figure class="news-thumb-wrap">
								<a href="'.get_the_permalink().'"><img src="'.$imgUrl.'" alt="'.get_the_title().'" /></a>
								'.$post_date.'
							</figure>
						</div>
						<div class="news-content">
							<div class="latest-news-para">
								<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>
								'.$shwmeta.'
								<p>'.content(of_get_option('latestnewslength')).'</p>
								<a href="'.get_the_permalink().'" class="ln-read-more">'.of_get_option('blogpostreadmoretext').'</a>
							</div>
						</div>
					</div>';
				elseif( $type == 'slider' ) :
					$postoutput .= '<div class="item"><div class="news-box">
						<div class="news-thumb">
							<figure class="news-thumb-wrap">
								<a href="'.get_the_permalink().'"><img src="'.$imgUrl.'" alt="'.get_the_title().'" /></a>
								'.$post_date.'
							</figure>
						</div>
						<div class="news-content">
							<div class="latest-news-para">
								<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>
								'.$shwmeta.'
								<p>'.content(of_get_option('latestnewslength')).'</p>
								<a href="'.get_the_permalink().'" class="ln-read-more">'.of_get_option('blogpostreadmoretext').'</a>
							</div>
						</div>
					</div></div>';
				endif;
		
			endwhile; wp_reset_postdata(); 
		
		else : 
			$postoutput .='<div class="text-center error_msg" style="display:table; margin:0 auto;">'.__('Sorry, No posts found.','cleaning').'</div>';
		endif; wp_reset_query();
		if( $type == 'slider' ) :  $postoutput .='</div>'; endif;
	$postoutput .= '<div class="clear"></div></div>';
	return $postoutput;
	
}
add_shortcode('latest-news','cleaning_latest_news_func');