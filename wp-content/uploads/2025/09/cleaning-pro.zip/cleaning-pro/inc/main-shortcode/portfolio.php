<?php
//custom post type for Portfolio
function my_custom_post_portfolio() {
	$labels = array(
		'name'               => __( 'Portfolios','cleaning' ),
		'singular_name'      => __( 'Portfolio','cleaning' ),
		'add_new'            => __( 'Add New','cleaning' ),
		'add_new_item'       => __( 'Add New Portfolio ','cleaning' ),
		'edit_item'          => __( 'Edit Portfolio','cleaning' ),
		'new_item'           => __( 'New Portfolio','cleaning' ),
		'all_items'          => __( 'All Portfolios','cleaning' ),
		'view_item'          => __( 'View Portfolio','cleaning' ),
		'search_items'       => __( 'Search Portfolios','cleaning' ),
		'not_found'          => __( 'No Portfolios found','cleaning' ),
		'not_found_in_trash' => __( 'No Portfolios found in the Trash','cleaning' ), 
		'parent_item_colon'  => '',
		'menu_name'          => 'Portfolios'
	);
	$args = array(
		'labels'        => $labels,
		'description'   => 'Manage Portfolios',
		'public'        => true,
		'menu_position' => null,
		'menu_icon'   => 'dashicons-index-card',
		'supports'      => array( 'title', 'thumbnail', 'editor' ),
		'has_archive'   => false,
	);
	register_post_type( 'portfolio', $args );
}
add_action( 'init', 'my_custom_post_portfolio' );
/******************************************************************************************/
//Register Category to Portfolio CPT
function taxonomies_portfolios() {
  $labels = array(
    'name'              => __( 'Portfolio Categories', 'cleaning' ),
    'singular_name'     => __( 'Category', 'cleaning' ),
    'search_items'      => __( 'Search Categories', 'cleaning' ),
    'all_items'         => __( 'All Categories', 'cleaning' ),
    'parent_item'       => __( 'Parent Category', 'cleaning' ),
    'parent_item_colon' => __( 'Parent Category:', 'cleaning' ),
    'edit_item'         => __( 'Edit Category', 'cleaning' ), 
    'update_item'       => __( 'Update Category', 'cleaning' ),
    'add_new_item'      => __( 'Add New Category', 'cleaning' ),
    'new_item_name'     => __( 'New Category', 'cleaning' ),
    'menu_name'         => __( 'Categories', 'cleaning' ),
  );
  $args = array(
    'labels' => $labels,
    'hierarchical' => true,
	'show_admin_column'	=>	true,
  );
  register_taxonomy( 'port_category', 'portfolio', $args );
}
add_action( 'init', 'taxonomies_portfolios', 0 );
/******************************************************************************************/
// Metabox for Portfolio CPT
function cleaning_portf_meta_box(){
	add_meta_box(
		'portf_gal_meta',
		'Add Portfolio Gallery Shortcode<br>(note:If you want to show images in portfolio add "Image Carousel/Portfolio Gallery" shortcode here, otherwise leave it blank. )',
		'display_portf_gal_meta',
		'portfolio','normal','default'
	);
	add_meta_box(
		'portf_info_meta',
		'Other Information',
		'display_portf_info_meta',
		'portfolio','normal','high'
	);
}
add_action('admin_init','cleaning_portf_meta_box');

function display_portf_gal_meta( $portfolio ){
	$portfgal = esc_html( get_post_meta( $portfolio->ID, '_portfgal', true ));
?>
<table width="100%">
    <tr>
        <td width="100%"><textarea name="portfgal" style="width:100%; height:150px;"><?php echo $portfgal; ?></textarea></td>
    </tr>
</table>
<?php }

function save_portf_gal_meta( $portfolio_id, $portfolio ){
	if ( $portfolio->post_type == 'portfolio' ) {
		if ( isset($_POST['portfgal']) ) {
            update_post_meta( $portfolio_id, '_portfgal', $_POST['portfgal'] );
        }
	}
}
add_action('save_post','save_portf_gal_meta',10,2);

function display_portf_info_meta( $portfolio1 ){
	$pdatelbl = esc_html( get_post_meta( $portfolio1->ID, '_pdatelbl', true ) );
	$pdate = esc_html( get_post_meta( $portfolio1->ID, '_pdate', true ) );
	$pclientlbl = esc_html( get_post_meta( $portfolio1->ID, '_pclientlbl', true ) );
	$pclient = esc_html( get_post_meta( $portfolio1->ID, '_pclient', true ) );
	$plocationlbl = esc_html( get_post_meta( $portfolio1->ID, '_plocationlbl', true ) );
	$plocation = esc_html( get_post_meta( $portfolio1->ID, '_plocation', true ) );
	$pvaluelbl = esc_html( get_post_meta( $portfolio1->ID, '_pvaluelbl', true ) );
	$pvalue = esc_html( get_post_meta( $portfolio1->ID, '_pvalue', true ) );
	$parchtlbl = esc_html( get_post_meta( $portfolio1->ID, '_parchtlbl', true ) );
	$parcht = esc_html( get_post_meta( $portfolio1->ID, '_parcht', true ) );
?>
<table width="100%">
	<tr>
        <td width="20%"><strong><?php _e('Field Name','cleaning');?></strong></td>
        <td width="40%"><strong><?php _e('Label','cleaning');?></strong></td>
        <td width="40%"><strong><?php _e('Value','cleaning');?></strong></td>
    </tr>
    <tr>
        <td width="20%">Project Date</td>
        <td width="40%"><input type="text" name="pdatelbl" value="<?php echo $pdatelbl; ?>" style="width:100%;" /></td>
        <td width="40%"><input type="text" name="pdate" value="<?php echo $pdate; ?>" style="width:100%;" /></td>
    </tr>
    <tr>
        <td width="20%">Project Client</td>
        <td width="40%"><input type="text" name="pclientlbl" value="<?php echo $pclientlbl; ?>" style="width:100%;" /></td>
        <td width="40%"><input type="text" name="pclient" value="<?php echo $pclient; ?>" style="width:100%;" /></td>
    </tr>
    <tr>
		<td width="20%">Project Location</td>
		<td width="40%"><input type="text" name="plocationlbl" value="<?php echo $plocationlbl; ?>" style="width:100%;" /></td>
		<td width="40%"><input type="text" name="plocation" value="<?php echo $plocation; ?>" style="width:100%;" /></td>
	</tr>
	<tr>
		<td width="20%">Project Value</td>
		<td width="40%"><input type="text" name="pvaluelbl" value="<?php echo $pvaluelbl; ?>" style="width:100%;" /></td>
		<td width="40%"><input type="text" name="pvalue" value="<?php echo $pvalue; ?>" style="width:100%;" /></td>
	</tr>
	<tr>
		<td width="20%">Project Architect</td>
		<td width="40%"><input type="text" name="parchtlbl" value="<?php echo $parchtlbl; ?>" style="width:100%;" /></td>
		<td width="40%"><input type="text" name="parcht" value="<?php echo $parcht; ?>" style="width:100%;" /></td>
	</tr>
</table>
<?php }
function save_portf_info_meta( $portfolio1_id, $portfolio1 ){
	if ( $portfolio1->post_type == 'portfolio' ) {
		if ( isset($_POST['pdatelbl']) ) {
            update_post_meta( $portfolio1_id, '_pdatelbl', $_POST['pdatelbl'] );
        }
		if ( isset($_POST['pdate']) ) {
            update_post_meta( $portfolio1_id, '_pdate', $_POST['pdate'] );
        }
        if ( isset($_POST['pclientlbl']) ) {
            update_post_meta( $portfolio1_id, '_pclientlbl', $_POST['pclientlbl'] );
        }
		if ( isset($_POST['pclient']) ) {
            update_post_meta( $portfolio1_id, '_pclient', $_POST['pclient'] );
        }
        if ( isset($_POST['plocationlbl']) ) {
            update_post_meta( $portfolio1_id, '_plocationlbl', $_POST['plocationlbl'] );
        }
		if ( isset($_POST['plocation']) ) {
            update_post_meta( $portfolio1_id, '_plocation', $_POST['plocation'] );
        }
        if ( isset($_POST['pvaluelbl']) ) {
            update_post_meta( $portfolio1_id, '_pvaluelbl', $_POST['pvaluelbl'] );
        }
		if ( isset($_POST['pvalue']) ) {
            update_post_meta( $portfolio1_id, '_pvalue', $_POST['pvalue'] );
        }
        if ( isset($_POST['parchtlbl']) ) {
            update_post_meta( $portfolio1_id, '_parchtlbl', $_POST['parchtlbl'] );
        }
		if ( isset($_POST['parcht']) ) {
            update_post_meta( $portfolio1_id, '_parcht', $_POST['parcht'] );
        }
	}
}
add_action('save_post','save_portf_info_meta',10,2);
/******************************************************************************************/
/* Portfolio Shortcode */
function cleaning_portfolio_shortcode_func( $atts ){
	extract( shortcode_atts( array(
		'show' => '-1',
		'type' => '',
		'filter' => 'true',
		'column' => '3'
	),$atts));
	
	$port = '';
	
	$port_query = new WP_Query( array(
		'post_type' => 'portfolio', 
		'posts_per_page' => $show,
		'orderby' => 'title',
    	'order'   => 'ASC',
	));
	
	if( $port_query->have_posts() ) :
		
		if( $type == 'grid' ){
			if( $filter == 'true' ){
				$port .= '<ul class="portfoliofilter clearfix"><li class="filter" data-filter="all">All</li>';
				$categories = get_categories( array('taxonomy' => 'port_category') );
				foreach ($categories as $category) {
					$port .= '<li class="filter" data-filter=".'.$category->slug.'">'.$category->name.'</li>';
				}
				$port .= '</ul>';
			}
		}

		if( $type == 'grid' ){
			$port .= '<div class="portfolio-main"><div id="mixitup">';
		} else {
			$port .= '<div class="portfolio-main"><div class="owl-carousel portf-rotator owl-theme">';
		}

		while( $port_query->have_posts() ) : $port_query->the_post();
			$terms = wp_get_post_terms( get_the_ID(), 'port_category', array("fields" => "all"));		
			$categories = get_the_category();
			$slugAr = array();
			foreach( $terms as $tv ){
				$slugAr[] = $tv->slug;
			}
			
			$imgSrcFull = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full');
			if ( $imgSrcFull[0]!='' ) {
				$imgFUrl = $imgSrcFull[0];
			}else{
				$imgFUrl = get_template_directory_uri().'/images/img_404.png';
			}
		
			$imgSrc = wp_get_attachment_image_src( get_post_thumbnail_id(), 'portf-post-thumb');
			if ( $imgSrc[0]!='' ) {
				$imgUrl = $imgSrc[0];
			}else{
				$imgUrl = get_template_directory_uri().'/images/img_404.png';
			}
			
			if( $column == 2 ){
				$shwgridcol = 'grid-col-two';
				$countcol = '1';
			}
			elseif( $column == 3 ){
				$shwgridcol = 'grid-col-three';
				$countcol = '2';
			}
			elseif( $column == 4 ){
				$shwgridcol = 'grid-col-four';
				$countcol = '3';
			}

			if( $type == 'grid'){	
				$port .= '<div class="mix '.$shwgridcol.' '.implode(' ', $slugAr).'"><div class="portfolio-image"><img src="'.$imgUrl.'" alt="'.get_the_title().'"><div class="portfolio-meta"><span><a href="'.get_the_permalink().'"><i class="far fa-link" aria-hidden="true"></i></a></span><span><a class="port-gallery" data-fancybox="group'.$countcol.'" data-thumb="'.$imgUrl.'" href="'.$imgSrcFull[0].'" data-caption="'.get_the_title().'"><i class="far fa-search-plus" aria-hidden="true"></i></a></span></div><div class="portfolio-title"><h3>'.get_the_title().'</h3></div></div></div><!-- mix -->';
			} elseif( $type == 'slider') {
				$port .= '<div class="items"><div class="portfolio-image"><img src="'.$imgUrl.'" alt="'.get_the_title().'"><div class="portfolio-meta"><span><a href="'.get_the_permalink().'"><i class="far fa-link" aria-hidden="true"></i></a></span><span><a class="port-gallery" data-fancybox="group'.$countcol.'" data-thumb="'.$imgUrl.'" href="'.$imgSrcFull[0].'" data-caption="'.get_the_title().'"><i class="far fa-search-plus" aria-hidden="true"></i></a></span></div><div class="portfolio-title"><h3>'.get_the_title().'</h3></div></div></div><!-- mix -->';
			}

		endwhile; wp_reset_postdata();

		$port .= '</div><!-- #mixitup --></div><!-- .portfolio main -->';

	else : 
		$port .='<div class="text-center error_msg" style="display:table; margin:0 auto;">'.__('Sorry, There are no Portfolio found','cleaning').'</div>';
	endif;
	
	return $port;
}
add_shortcode('portfolio','cleaning_portfolio_shortcode_func');