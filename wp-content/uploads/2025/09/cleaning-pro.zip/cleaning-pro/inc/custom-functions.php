<?php
/**
 * @package Cleaning Pro
 * Setup the WordPress core custom functions feature.
 *
*/

add_action('cleaning_optionsframework_custom_scripts', 'cleaning_optionsframework_custom_scripts');
function cleaning_optionsframework_custom_scripts() { ?>
	<script type="text/javascript">
    jQuery(document).ready(function() {
    
        jQuery('#example_showhidden').click(function() {
            jQuery('#section-example_text_hidden').fadeToggle(400);
        });
        
        if (jQuery('#example_showhidden:checked').val() !== undefined) {
            jQuery('#section-example_text_hidden').show();
        }
        
    });
    </script><?php
}

// get_the_content format text
function get_the_content_format( $str ){
	$raw_content = apply_filters( 'the_content', $str );
	$content = str_replace( ']]>', ']]&gt;', $raw_content );
	return $content;
}
// the_content format text
function the_content_format( $str ){
	echo get_the_content_format( $str );
}

function is_google_font( $font ){
	$notGoogleFont = array( 'Arial', 'Comic Sans MS', 'FreeSans', 'Georgia', 'Lucida Sans Unicode', 'Palatino Linotype', 'Symbol', 'Tahoma', 'Trebuchet MS', 'Verdana' );
	if( in_array($font, $notGoogleFont) ){
		return false;
	}else{
		return true;
	}
}

// subhead section function
function sub_head_section( $more ) {
	$pgs = 0;
	do {
		$pgs++;
	} while ($more > $pgs);
	return $pgs;
}

//[clear]
function clear_func() {
	$clr = '<div class="clear"></div>';
	return $clr;
}
add_shortcode( 'clear', 'clear_func' );


//[column_content]Your content here...[/column_content]
function column_content_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => '',	
		'subcls' => '',
	), $atts ) );
	$colPos = strpos($type, '_last');
	if($colPos === false){
		$cnt = '<div class="'.$type.' '.$subcls.'">'.get_the_content_format( do_shortcode($content) ).'</div>';
	}else{
		$type = substr($type,0,$colPos);
		$cnt = '<div class="'.$type.' '.$subcls.' last_column">'.get_the_content_format( do_shortcode($content) ).'</div>';
	}
	return $cnt;
}
add_shortcode( 'column_content', 'column_content_func' );


//[hr]
function hrule_func() {
	$hrule = '<div class="hr"></div>';
	return $hrule;
}
add_shortcode( 'hr', 'hrule_func' );


//[hr_top]
function back_to_top_func() {
	$back_top = '<div id="back-top">
		<a title="Top of Page" href="#top"><span><i class="far fa-'.of_get_option('backtpicn',true).'" aria-hidden="true"></i></span></a>
	</div>';
	return $back_top;
}
add_shortcode( 'back-to-top', 'back_to_top_func' );


// [searchform]
function searchform_shortcode_func( $atts ){
	return get_search_form( false );
}
add_shortcode( 'searchform', 'searchform_shortcode_func' );

// accordion
function accordion_func( $atts, $content = null ) {
	$acc = '<div class="customtab">'.get_the_content_format( do_shortcode($content) ).'<div class="clear"></div></div>';
	return $acc;
}
add_shortcode( 'accordion', 'accordion_func' );
function accordion_content_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'Accordion Title',
	), $atts ) );
	$content = wpautop(trim($content));
	$acn = '<div class="accordion-box"><h2>'.$title.'</h2>
			<div class="acc-content">'.$content.'</div><div class="clear"></div></div>';
	return $acn;
}
add_shortcode( 'accordion_content', 'accordion_content_func' );


// remove excerpt more
function new_excerpt_more( $more ) {
	return '... ';
}
add_filter('excerpt_more', 'new_excerpt_more');

// get post categories function
function getPostCategories(){
	$categories = get_the_category();
	$catOut = '';
	$separator = ' ';
	$catOutput = '';
	if($categories){
		foreach($categories as $category) {
			$catOutput .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s", 'cleaning' ), $category->name ) ) . '">'.$category->cat_name.'</a>'.$separator;
		}
		$catOut = ''.trim($catOutput, $separator);
	}
	return $catOut;
}


// replace last occurance of a string.
function str_lreplace($search, $replace, $subject){
	$pos = strrpos($subject, $search);
	if($pos !== false){
		$subject = substr_replace($subject, $replace, $pos, strlen($search));
	}
	return $subject;
}

//Gradient button
function gradient_button_func( $atts ) {
	extract( shortcode_atts( array(
		'size' => 'small',
		'bg_color' => '#636b74',
		'color' => '#fff',
		'text' => 'More',
		'title' => 'Click',
		'url' => '',
		'position' => 'center',
	), $atts ) );
	$btn  = "<div class=\"clear\"></div>";
	$btn .= "<a href=\"{$url}\" ";
	$btn .= ($title != "") ? " title=\"{$title}\" " : "";
	$btn .= "class=\"grad-btn-{$size} btn-align-{$position}\" style=\"background-color:{$bg_color}; color:{$color}\">";
	$btn .= "{$text}</a>";
	$btn  .= "<div class=\"clear\"></div>";

	return $btn;
}
add_shortcode( 'gradient_button', 'gradient_button_func' );

//Simple Button
function simple_button_func( $atts ) {
	extract( shortcode_atts( array(
		'size' => 'small',
		'bg_color' => '#636b74',
		'color' => '#fff',
		'text' => 'More',
		'title' => 'Click',
		'url' => '',
		'position' => 'left',
	), $atts ) );
	$btn  = "<div class=\"clear\"></div>";
	$btn .= "<a href=\"{$url}\" ";
	$btn .= ($title != "") ? " title=\"{$title}\" " : "";
	$btn .= "class=\"simple-btn-{$size} btn-align-{$position}\" style=\"background-color:{$bg_color}; color:{$color}\">";
	$btn .= "{$text}</a>";
	$btn  .= "<div class=\"clear\"></div>";

	return $btn;
}
add_shortcode( 'simple_button', 'simple_button_func' );

//Round Button
function round_button_func( $atts ) {
	extract( shortcode_atts( array(
		'style' => 'dark',
		'text' => 'More',
		'title' => 'Click',
		'url' => '',
		'position' => 'left',
	), $atts ) );
	$btn  = "<div class=\"clear\"></div>";
	$btn .= "<a href=\"{$url}\" ";
	$btn .= ($title != "") ? " title=\"{$title}\" " : "";
	$btn .= "class=\"round-btn-{$style} round-btn btn-align-{$position}\">";
	$btn .= "<span>{$text}</span></a>";
	$btn  .= "<div class=\"clear\"></div>";

	return $btn;
}
add_shortcode( 'round_button', 'round_button_func' );

//MEssage Info 
function msg_box_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 'info',
		'bg_color' => '#f6f6f6',
		'color' => '#333',
		'start_color' => "#fff",
		'end_color' => "#eee",
		'border' => "#ccc",
		'align' => '',
		'width' => '100%',
	), $atts ) );
	$msg = '';

	if($type == 'success'){
		$msg  = '<div class="msg-success"><div class="msg-box-icon">';
		$msg .= ($content == '') ? "This is a sample of the 'success' style message box shortcode. To use this style use the following shortcode" : $content;
		$msg .= '</div></div>';
	}elseif($type == 'error'){
		$msg  = '<div class="msg-error"><div class="msg-box-icon">';
		$msg .= ($content == '') ? "This is a sample of the 'error' style message box shortcode. To use this style use the following shortcode." : $content;
		$msg .= '</div></div>';
	}elseif($type == 'warning'){
		$msg  = '<div class="msg-warning"><div class="msg-box-icon">';
		$msg .= ($content == '') ? "This is a sample of the 'warning' style message box shortcode. To use this style use the following shortcode." : $content;
		$msg .= '</div></div>';
	}elseif($type == 'info'){
		$msg  = '<div class="msg-info"><div class="msg-box-icon">';
		$msg .= ($content == '') ? "This is a sample of the 'info' style message box shortcode. To use this style use the following shortcode." : $content;
		$msg .= '</div></div>';
	}elseif($type == 'about'){
		$msg  = '<div class="msg-about"><div class="msg-box-icon">';
		$msg .= ($content == '') ? "This is a sample of the 'about' style message box shortcode. To use this style use the following shortcode." : $content;
		$msg .= '</div></div>';
	}elseif($type == 'custom'){
		$msg  = "<div style=\"width:{$width};\" class=\"msg-align-{$align}\"><div class=\"msg-custom\" style=\"background-color:{$end_color}; background:   -moz-linear-gradient(center top , {$start_color}, {$end_color}); background: -webkit-gradient(linear, 0% 0%, 0% 100%, from({$start_color}), to({$end_color})); background: -webkit-linear-gradient(top, {$start_color}, {$end_color}); background: -ms-linear-gradient(top, {$start_color}, {$end_color}); background: -o-linear-gradient(top, {$start_color}, {$end_color}); border:1px {$border} solid; color:{$color};\">"; 
		$msg .= ($content == '') ? "This is a sample of the 'simple' style message box shortcode." : $content;
		$msg .= '</div></div><div class="clear"></div>';
	}elseif($type == 'simple'){
		$msg  = "<div class=\"msg-simple\" style=\"background-color:{$bg_color}; color:{$color};\">";
		$msg .= ($content == '') ? "This is a sample of the 'simple' style message box shortcode." : $content;
		$msg .= '</div>';
	}
	return $msg;
}
add_shortcode( 'message', 'msg_box_func' );

// List Style
function unorderedlist_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => 'list-1',
	), $atts ) );
	$content = wpautop(trim($content));
	$ulist = '<ul class="'.$style.'">'.$content.'</ul>';
	return $ulist;
}
add_shortcode( 'unordered_list', 'unorderedlist_func' );

//Dropcap
function dropcap_func( $atts, $content = null ) {
	$dcap = '<span class="dropcap">'.$content.'</span>';
	return $dcap;
}
add_shortcode( 'dropcap', 'dropcap_func' );

//Blockquote
function blkquote_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'align' => '',
	), $atts ) );
	$quote = ($content == '' ) ? "<blockquote class=\"align-{$align}\">This is a pullquote. Lorem ipsum dolor sit amet, consectetur adipiscing elit sed pharetra aliquet metus.</blockquote>" : "<blockquote class=\"align-{$align}\">$content</blockquote>";

	return $quote;
}
add_shortcode( 'blockquote', 'blkquote_func' );

//Youtube video 
function cleaning_youtube_vid($atts,$content = null){
	extract( shortcode_atts( array(
		'vid_identifier' => '',
	),$atts));
	return'<div class="youtube-vid"><iframe height="240" width="320" src="//www.youtube.com/embed/'.$vid_identifier.'?rel=0&showinfo=0&controls=1;" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>';
}
add_shortcode('youtube','cleaning_youtube_vid');

//Vimeo Video
function cleaning_vimoe_vid($atts,$content = null){
	extract( shortcode_atts( array(
		'vid_identifier' => '',
	),$atts));
	return'<div class="vimeo-vid"><iframe src="//player.vimeo.com/video/'.$vid_identifier.'?title=0&byline=0&portrait=0&autoplay=0&rel=0;" height="240" width="320" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>';
}
add_shortcode('vimeo','cleaning_vimoe_vid');

// Social Icon Shortcodes
function cleaning_social_area($atts,$content = null){
  return '<div class="social-icons">'.do_shortcode($content).'</div>';
 }
add_shortcode('social_area','cleaning_social_area');

function cleaning_social($atts){
 extract(shortcode_atts(array(
  'icon' => '',
  'link' => ''
 ),$atts));
  return '<a href="'.$link.'" target="_blank" title="'.$icon.'"><i class="fab fa-'.$icon.'"></i></a>';
 }
add_shortcode('social','cleaning_social');

/*toggle function*/
function toggle_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'Click here to toggle content',
	), $atts ) );
	$tog_content = "<div class=\"toggle_holder\"><h3 class=\"slide_toggle\"><a href=\"#\">{$title}</a></h3>
					<div class=\"slide_toggle_content\">".get_the_content_format( $content )."</div></div>";

	return $tog_content;
}
add_shortcode( 'toggle_content', 'toggle_func' );

function tabs_func( $atts, $content = null ) {
	$tabs = '<div class="tabs-wrapper"><ul class="tabs">'.do_shortcode($content).'</ul></div>';
	return $tabs;
}
add_shortcode( 'tabs', 'tabs_func' );

function tab_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'Tab Title',
	), $atts ) );
	$rand = rand(100,999);
	$tab = '<li><a rel="tab'.$rand.'" href="javascript:void(0)">'.$title.'</a><div id="tab'.$rand.'" class="tab-content">'.get_the_content_format($content).'</div></li>';
	return $tab;
}
add_shortcode( 'tab', 'tab_func' );

// Button Shortcode
function readmorebtn_fun($atts){
	extract(shortcode_atts(array(
	'name'	=> '',
	'align'	=> '',
	'link'	=> '#'	
	), $atts));
	return '<div class="custombtn" style="text-align:'.$align.'">	
	   <a class="main-button" href="'.$link.'"><span>'.$name.'</span></a>	   	   
	</div>';
	}
add_shortcode('button','readmorebtn_fun');

// Button Shortcode
function readmorebtn_style2_fun($atts){
	extract(shortcode_atts(array(
	'name'	=> '',
	'align'	=> '',
	'link'	=> '#'	
	), $atts));
	return '<div class="custombtn" style="text-align:'.$align.'">	
	   			<a class="buttonstyle1" href="'.$link.'"><span>'.$name.'</span></a>	   	   
			</div>';
	}
add_shortcode('buttonstyle2','readmorebtn_style2_fun');


// add shortcode for skills
function cleaning_skills($cleaning_skill_var){
	extract( shortcode_atts(array(
		'title' 	=> 'title',
		'percent'	=> 'percent',
	), $cleaning_skill_var));
	
	return '<div class="skillbar clearfix " data-percent="'.$percent.'%">
			<div class="skillbar-title"><span>'.$title.'</span></div>
			<div class="skill-bg"><div class="skillbar-bar"></div></div>
			<div class="skill-bar-percent">'.$percent.'%</div>
			</div>';
}

add_shortcode('skill','cleaning_skills');

//Spacer Shortcode
function cleaning_spacer($atts){
	extract(shortcode_atts(array(
		'space' => '',
	), $atts));
	return '<div style="height:'.$space.'px"></div>';
	}
add_shortcode('spacer', 'cleaning_spacer');

// add shortcode for Counter
function cleaning_counter_wrap( $atts, $content = null ){
	$counter = '<div class="counter-main">'.do_shortcode($content).'</div>';
	return $counter;
}
add_shortcode('counter_wrap','cleaning_counter_wrap');
function cleaning_counter($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	=> '',
		'count'	=> '',
		'plus' => '',
		'bg_color' => '',
		'number_color' => '',
		'title_color' => '',
	), $atts));

	return '<div class="counter-box" style="border-color:'.$number_color.';background-color:'.$bg_color.'">	
				<div class="inner-counter">
					<h3 class="counter" style="color:'.$number_color.'">'.$count.'</h3>'.(($plus == 'yes') ? '<span style="color:'.$number_color.'">+</span>' : '').'
					<h3 class="counter-ttl" style="color:'.$title_color.'">'.$title.'</h3>
				</div>
			</div>';
}
add_shortcode('counter','cleaning_counter');

/*Clients Logo function*/
function cleaning_client_logos($atts, $content = null){
  return '<div class="partners owl-carousel owl-theme">'.do_shortcode($content).'</div>';
  }
add_shortcode('client_lists','cleaning_client_logos');

function cleaning_client($atts){
  extract(shortcode_atts(array(
  'image'  => '',
  'link'  => '#'  
  ), $atts));
  return '<div class="item"><div class="partner-logo"><a href="'.$link.'" target="_blank"><img src="'.$image.'" /></a></div></div>';
  }
add_shortcode('client','cleaning_client');

//Section title
function cleaning_sec_ttl($atts){
	extract( shortcode_atts( array(
		'sub_title' => '',
		'title' => '',
		'section_text' => '',
	), $atts));
	
	return'<div class="section_head"><h4 class="section_sub_title">'.$sub_title.'</h4><h2 class="section_title">'.$title.'</h2><p>'.$section_text.'</p></div>';	
}
add_shortcode('section_title','cleaning_sec_ttl');

//Custom Heading
function cleaning_cust_heading($atts){
	extract( shortcode_atts( array(
		'sml_ttl' =>'',
		'title' => '',
		'title_color' => '',
		'sml_title_color' => '',
		'font_size'	 =>	'',
		'font_family'	=> '',
		'align' => '',
	), $atts));
	
	return'<div class="custom-heading" style="text-align:'.$align.'; font-size:'.$font_size.'; font-family:'.$font_family.';">
				<h2 style="color:'.$title_color.';font-size:'.$font_size.'; font-family:'.$font_family.';"><span style="color:'.$sml_title_color.'">'.$sml_ttl.'</span>'.$title.'</h2>
			</div>';	
}
add_shortcode('custom_heading','cleaning_cust_heading');

// Section Code
function cleaning_section_code_func( $atts, $content = null ){
	extract( shortcode_atts( array(
		'animation_type'	=>	'',
		'background_image'	=>	'',
		'background_color'	=>	'',
		'container_class'	=>	'',
		'section_title'		=>	'',
		'section_sub_title'	=>	'',
		'section_text'		=>	'',
		'section_class'		=>	'',
	), $atts));
	
	$sec_bg_img = '';
	$sec_title = '';
	$sec_bg_clr = '';

	if ( $section_title != ''  ) :
		$sec_title = '<div class="section_head">
			<h4 class="section_sub_title">'.$section_sub_title.'</h4>
			<h2 class="section_title"><span>'.$section_title.'</span></h2>
			<p>'.$section_text.'</p>
		</div><!-- section head -->';
	endif;
	
	if ( $background_image != '' ):
		$sec_bg_img	= 'background-image:url('.$background_image.');';
	endif;
	
	if ( $background_color != '' ):
		$sec_bg_clr	= 'background-color:'.$background_color.';';
	endif;
	
	return '<section class="section-content '.$section_class.'" style="'.$sec_bg_img.' '.$sec_bg_clr.'">
				<div class="'.$container_class.'">
					<div class="wow '.$animation_type.'" data-wow-duration="3s">
						'.$sec_title.'
						'.get_the_content_format( $content ).'
					</div><!-- animation class -->
				</div><!-- container class -->								
			</section><!-- section -->';
}
add_shortcode('section','cleaning_section_code_func');

//Image Carousel PORTFOLIO GALLERY
function cleaning_image_carousel_wrap( $atts, $content = null ){
	$img_caro_wrap = '<div class="image-carousel"><ul id="portfolio-gallery" class="gallery list-unstyled cS-hidden">'.get_the_content_format( do_shortcode($content) ).'</ul></div>';
	return $img_caro_wrap;
}
add_shortcode('image_carousel','cleaning_image_carousel_wrap');

function cleaning_carousel_image( $atts ){
	extract( shortcode_atts( array(
		'path' => '',
	), $atts ) );
	
	return '<li data-thumb="'.$path.'"><a href="'.$path.'" data-fancybox="images"><img src="'.$path.'" /></a></li>';

}
add_shortcode('image','cleaning_carousel_image');

/* ===================================== Theme Shortcode =======================================*/

// Icon Box
function cleaning_icon_box_func( $atts, $content = null ){
	extract( shortcode_atts(array(
		'icon' => '',
		'icon_style' => '',
		'title' => '',
		'link' => '',
	),$atts));

	if($icon_style == 'regular'){
		$shw_icon_style ='r';
	} elseif($icon_style == 'light'){
		$shw_icon_style ='l';
	} elseif($icon_style == 'solid'){
		$shw_icon_style ='s';
	} elseif($icon_style == 'brand'){
		$shw_icon_style ='b';
	}

	if( !empty($icon)){
		$shwicon = '<div class="icon-box-icon"><i class="fa'.$shw_icon_style.' fa-'.$icon.'" aria-hidden="true"></i></div><!-- Icon Box -->';
	}if( !empty($title)){
		$shwttl = '<h5><a href="'.$link.'">'.$title.'</a></h5>';
	}

	return '<div class="icon-box"><div class="inner-icon-box flex-element">'.$shwicon.'<div class="icon-box-content">'.$shwttl.'<p>'.$content.'</p></div></div></div>';
}
add_shortcode('icon_box','cleaning_icon_box_func');

//image icon box
function cleaning_image_box_func( $atts, $content = null ){
	extract( shortcode_atts( array(
		'image' => '',
		'title' => '',
		'link' => '',
		'button_text' => '',
	),$atts));

	if( !empty( $button_text ) ){
		$shwbtn = '<a href="'.$link.'" class="buttonstyle1">'.$button_text.'</a>';
	}

	return '<div class="image-box"><div class="image-box-thumb"><a href="'.$link.'"><img src="'.$image.'"></a></div><div class="image-box-content"><div class="image-box-inner-content"><h4><a href="'.$link.'">'.$title.'</a></h4><p>'.$content.'</p>'.$shwbtn.'</div></div></div>';
}
add_shortcode('image_box','cleaning_image_box_func');

// Add shortcode for Introduction section
function  cleaning_introduction_func( $atts, $content = null ){
	extract( shortcode_atts( array(
		'image' => '',
		'image_position' => '',
		'sub_title' => '',
		'title' => '',
		'since' => '',
	),$atts));

	if( !empty( $title ) ) {
		$shwttl = '<div class="section_head text-left mb-10"><h4 class="section_sub_title">'.$sub_title.'</h4><h2 class="section_title">'.$title.'</h2></div>';
	}if( $image_position == 'right' ){
		$shwimgpos = ' right-side';
	}

	$getcont_mod = get_the_content_format( do_shortcode($content) );

	if( $image_position == 'left' ){
		$shwdetails = '<div class="introduction-box"><div class="about_fig"><figure style="background-image:url('.$image.');"></figure></div><!-- about_fig --><div class="about_content">'.$shwttl.'<p>'.$getcont_mod.'</p></div><!-- about_content --><div class="clear"></div></div><!-- introduction box -->';
	}elseif ( $image_position == 'right' ) {
		$shwdetails = '<div class="introduction-box'.$shwimgpos.'"><div class="about_content">'.$shwttl.'<p>'.$getcont_mod.'</p></div><!-- about_content --><div class="about_fig"><figure style="background-image:url('.$image.');"></figure></div><!-- about_fig --><div class="clear"></div></div><!-- introduction box -->';
	}
	
	return $shwdetails;
}
add_shortcode('introduction','cleaning_introduction_func');

//Info box
function cleaning_information_box_func( $atts, $content = null ){
	extract( shortcode_atts( array(
		'icon' => '',
		'icon_style' => 'light',
		'title' => '',
		'link' => '',
	),$atts));

	if($icon_style == 'regular'){
		$shw_icon_style ='r';
	} elseif($icon_style == 'light'){
		$shw_icon_style ='l';
	} elseif($icon_style == 'solid'){
		$shw_icon_style ='s';
	} elseif($icon_style == 'brand'){
		$shw_icon_style ='b';
	}

	if( !empty($icon)){
		$shwinfoicon = '<div class="info-box-icon"><i class="fa'.$shw_icon_style.' fa-'.$icon.'" aria-hidden="true"></i></div><!-- info Box icon -->';
	}if( !empty($title)){
		$shwinfottl = '<h4><a href="'.$link.'">'.$title.'</a></h4>';
	}

	$shwinfofucn = '<div class="info-box"><div class="inner-info-box">'.$shwinfoicon.'<div class="info-box-cont">'.$shwinfottl.'<p>'.$content.'</p></div></div></div>';

	return $shwinfofucn;
}
add_shortcode('info_box','cleaning_information_box_func');

//popup video
function cleaning_popup_func( $atts ){
	extract( shortcode_atts(array(
		'video_link' => '',
	),$atts));
	
	return '<div class="pop-video"><div class="inner-pop-video"><div class="pop-icon"><a data-fancybox data-width="1060" data-height="600" href="'.$video_link.'"><i class="fal fa-play-circle"></i></a></div></div></div>';
}
add_shortcode('popup_video','cleaning_popup_func');

// Pricing List
function cleaning_pricing_plan_func( $atts ){
	extract(shortcode_atts( array(
		'title' => '',
		'price' => '',
		'price_sign' => '',
		'duration' => '',
		'highlight'	=>	'',
		'row1'	=>	'',
		'row2'	=>	'',
		'row3'	=>	'',
		'row4'	=>	'',
		'row5'	=>	'',
		'row6'	=>	'',
		'row7'	=>	'',
		'row8'	=>	'',
		'row9'	=>	'',
		'row10'	=>	'',
		'btn_label'	=>	'',
		'link'	=>	''
	),$atts));
	
	return'<div class="pricing-col'.(($highlight == 'yes') ? ' highlighted-col' : '').'">
				<div class="package-name">
					<h2>'.$title.'</h2>
				</div>
				<div class="package-price">
					<sup>'.$price_sign.' </sup>'.$price.'<sub> / '.$duration.'</sub>
				</div>
				<div class="package-row">
					'.(($row1 != '') ? '<p>'.$row1.'</p>' : '').'
					'.(($row2 != '') ? '<p>'.$row2.'</p>' : '').'
					'.(($row3 != '') ? '<p>'.$row3.'</p>' : '').'
					'.(($row4 != '') ? '<p>'.$row4.'</p>' : '').'
					'.(($row5 != '') ? '<p>'.$row5.'</p>' : '').'
					'.(($row6 != '') ? '<p>'.$row6.'</p>' : '').'
					'.(($row7 != '') ? '<p>'.$row7.'</p>' : '').'
					'.(($row8 != '') ? '<p>'.$row8.'</p>' : '').'
					'.(($row9 != '') ? '<p>'.$row9.'</p>' : '').'
					'.(($row10 != '') ? '<p>'.$row10.'</p>' : '').'
				</div>
				<div class="package-btn">
					<a href="'.$link.'" class="main-button">'.$btn_label.'</a>
				</div>
		   </div>';
}
add_shortcode('pricing-plan','cleaning_pricing_plan_func');

define('FLY_THEME_DOC','flythemesdemo.net/documentation/cleaning-doc/');