<style>
body{ color:#797878; font-size:13px; font-family:'Sintony'; font-weight:400; }

/* Heading tag */
h1,h2,h3,h4,h5,h6{font-family:'Montserrat'; font-weight:700; }
h1{font-size:34px;color:#444444;}
h2{font-size:26px;color:#444444;}
h3{font-size:22px;color:#444444;}
h4{font-size:18px;color:#444444;}
h5{font-size:16px;color:#444444;}
h6{font-size:14px;color:#444444;}

.nivo-controlNav, .nivo-directionNav{ display:none; }

.slider-main{ background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/images/loading.gif); }

/*Link Color*/
a, .slide_toggle a, .postby a, .news-box .PostMeta a, .post-title a{color:#444444;}
a:hover, .slide_toggle a:hover, .news-box h6 a:hover, .postby a:hover, .news-box .PostMeta a:hover, #sidebar .quotes h6 a{color:#ffd527;}

/* Buttons */
a.morebutton, a.main-button, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .headertop .right a, .wpcf7 form input[type='submit'], .pagination ul li .current, .pagination ul li a:hover, #sidebar .search-form input.search-submit, .owl-prev, .owl-next, .foo-subscribe button{background-color:#ffd527;}
a.button, a.morebutton, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit, .contact_right .contactdetail a{color:#ffffff;}
a.morebutton:hover, a.main-button:hover, #commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, p.read-more a:hover, .headertop .right a:hover, .wpcf7 form input[type='submit']:hover, #sidebar .search-form input.search-field, .pagination ul li span, .pagination ul li a, .owl-prev:hover, .owl-next:hover, .foo-subscribe button:hover{background-color:#28c6f2;color:#ffffff; }
a.buttonstyle1 { color:#ffffff; background-color:#28c6f2; }
a.buttonstyle1:hover { color:#ffffff; background-color:#ffd527; }

#mixitup .mix{ float:left; }

</style>
<script src="https://kit.fontawesome.com/a05eda20c4.js"></script>

<body id="top" class="home blog logged-in">
	<div id="pagewrap">

        <header class="header-responsive">
            <div class="top-header-toggle">
                <a href="#" class="tp-head-toggle main-button"><i class="far fa-chevron-down"></i></a>
            </div>
            <div class="top-header">
                <div class="container">
                    <div class="side-border">
                        <div class="flex-element">
                            <div class="top-header-col big"> Professional Cleaning Services For all Your Need </div>
                            <div class="top-header-col big text-center">
                                <div class="social-icons">
                                    <a href="#" target="_blank" title="twitter"><i class="fab fa-twitter"></i></a>
                                    <a href="#" target="_blank" title="facebook-f"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" target="_blank" title="youtube"><i class="fab fa-youtube"></i></a>
                                    <a href="#" target="_blank" title="linkedin-in"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#" target="_blank" title="pinterest-p"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                            <div class="top-header-col small text-right icon-phn">
                                <a href="mailto:+01 888 888 8888">+01 888 888 8888</a>
                            </div>
                            <div class="top-header-col small text-right icon-mail">
                                <a href="mailto:info@sitename.com">info@sitename.com</a>
                            </div>

                        </div><!-- flex elements -->
                    </div><!-- side border -->
                </div><!-- container -->
            </div><!-- top header -->

            <div class="container">
                <div class="logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo.png">
                    </a>
                </div><!-- Logo -->
                <div class="toggle">
                    <a class="toggleMenu" href="#"></a>
                </div><!-- toggle --><div class="clear"></div>
                <div class="sitenav">                   
                    <div class="container">
                        <ul>
                            <li class="current-menu-item current_page_item">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-current="page">Home</a>
                            </li>
                            <li><a href="#">Sample Page</a></li>
                        </ul>
                        <div class="header-btn">
                            <a href="#" class="main-button">Request A Quote</a>
                        </div>
                    </div>
                </div><!--.sitenav -->
            </div><!-- container -->
        </header><!-- header responsive -->

        <div class="header-main">

            <div class="top-header">
                <div class="container">
                    <div class="side-border">
                        <div class="flex-element">

                            <div class="top-header-col big">
                                Professional Cleaning Services For all Your Need
                            </div>
                            <div class="top-header-col big text-center">
                                <div class="social-icons">
                                    <a href="#" target="_blank" title="twitter"><i class="fab fa-twitter"></i></a>
                                    <a href="#" target="_blank" title="facebook-f"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" target="_blank" title="youtube"><i class="fab fa-youtube"></i></a>
                                    <a href="#" target="_blank" title="linkedin-in"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#" target="_blank" title="pinterest-p"><i class="fab fa-pinterest-p"></i></a>
                                </div>                
                            </div>
                            <div class="top-header-col small text-right icon-phn">
                                <a href="mailto:+01 888 888 8888">+01 888 888 8888</a>
                            </div>
                            <div class="top-header-col small text-right icon-mail">
                                <a href="mailto:info@sitename.com">info@sitename.com</a>
                            </div>

                        </div><!-- flex elements -->
                    </div><!-- side border -->
                </div><!-- container -->
            </div><!-- top header -->

            <header class="header">
                <div class="container">
                    <div class="flex-element">

                        <div class="header-left">
                            <div class="logo">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo.png">
                                </a>
                            </div><!-- .logo -->
                        </div><!-- header left -->
                        <div class="header-right">
                            <div class="toggle">
                                <a class="toggleMenu" href="#"></a>
                            </div><!-- toggle -->
                            <div class="sitenav">
                                <ul>
                                    <li class="current-menu-item current_page_item">
                                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-current="page">Home</a>
                                    </li>
                                    <li><a href="#">Sample Page</a></li>
                                </ul>
                            </div><!--.sitenav -->
                        </div><!-- header right -->
                        <div class="header-btn">
                            <a href="#" class="main-button">Request A Quote</a>
                        </div>    

                    </div><!-- flex elements -->
                </div><!-- container -->
            </header><!-- header -->
        </div><!-- header main -->
            
        <div class="slider-main">
            <div id="slider" class="nivoSlider caption-text-left">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/slides/slider1.jpg" alt="Read More" class="nivo-overlay" title="#slidecaption1" />
            </div><!-- slider --> 
            <div id="slidecaption1" class="nivo-html-caption">
                <a href="#"><h2>We keep Your World Fresh &amp; Sparkling Clean</h2></a>
                <p>Donec pretium, neque vel lobortis congue, mi eros faucibus purus, eu hendrerit diam sem non sapien. Nam eleifend orci massa. Aenean consectetur pulvinar metus quis blandit. Maecenas aliquam ultrices dapibus. Aenean in quam quis metus pellentesque blandit at in nulla. Etiam tempus iaculis justo, vitae sagittis tellus placerat eget.</p><div class="clear"></div>
                <a href="#" class="sliderbtn">
                    <span>How we do it</span>
                </a>
            </div><!-- nivo-html-caption -->
        </div><!-- slider-main -->

        <!-- ***************************************************************************************** -->

        <section style="background-color:#ffffff;">
            <div class="container">
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="one_third section-title-nbdr">
                        <div class="section_head">
                            <h4 class="section_sub_title">WELCOME TO OUR</h4>
                            <h2 class="section_title">CLEANING SERVICES</h2>
                        </div>
                        <p> Suspendisse nisl ex, interdum sed libero vitae, convallis elementum mi. Vestibulum odio ante, accumsan id risus imperdiet, venenatis lobortis mi. In non nisi mi. Curabitur tempus, erat eu porta hendrerit, eros quam ullamcorper leo, sed lacinia neque urna nec urna.</p>
                        <div class="custombtn" style="text-align:left">
                            <a class="main-button" href="/about"><span>Read More</span></a>
                        </div>
                    </div>

                    <div class="one_third">
                        <div class="icon-box">
                            <div class="inner-icon-box flex-element">
                                <div class="icon-box-icon"><i class="fal fa-bookmark" aria-hidden="true"></i></div><!-- Icon Box -->
                                <div class="icon-box-content">
                                    <h5><a href="#">Flexible Cleaning Plans</a></h5>
                                    <p> venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. </p>
                                </div>
                            </div>
                        </div>
                        <div class="icon-box">
                            <div class="inner-icon-box flex-element">
                                <div class="icon-box-icon"><i class="fas fa-leaf" aria-hidden="true"></i></div><!-- Icon Box -->
                                <div class="icon-box-content">
                                    <h5><a href="#">Green Cleaning Solution</a></h5>
                                    <p> venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="one_third last_column">
                        <div class="icon-box">
                            <div class="inner-icon-box flex-element">
                                <div class="icon-box-icon"><i class="fal fa-user" aria-hidden="true"></i></div><!-- Icon Box -->
                                <div class="icon-box-content">
                                    <h5><a href="#">Verified Employees</a></h5>
                                    <p> venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. </p>
                                </div>
                            </div>
                        </div>
                        <div class="icon-box">
                            <div class="inner-icon-box flex-element">
                                <div class="icon-box-icon"><i class="far fa-life-ring" aria-hidden="true"></i></div><!-- Icon Box -->
                                <div class="icon-box-content">
                                    <h5><a href="#">Best Customer Support</a></h5>
                                    <p> venenatis sapien, vitae efficitur velit. Mauris eget mattis justo, in luctus erat. </p>
                                </div>
                            </div>
                        </div>
                    </div><div class="clear"></div>

                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>

        <!-- ***************************************************************************************** -->
        
        <section style="background-color:#f8f8f8;">
            <div class="container">
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="introduction-box right-side">
                        <div class="about_content">
                            <div class="section_head text-left mb-10">
                                <h4 class="section_sub_title">A Trusted Cleaning Company</h4>
                                <h2 class="section_title">High Quality & Best Cleaning Services</h2>
                            </div>
                            <p> Suspendisse nisl ex, interdum sed libero vitae, convallis elementum mi. Vestibulum odio ante, accumsan id risus imperdiet, venenatis lobortis mi. In non nisi mi. Curabitur tempus, erat eu porta hendrerit, eros quam ullamcorper leo, sed lacinia neque urna nec urna.</p>
                            <p>Suspendisse eu ultrices dui, in lobortis odio. Duis ac lobortis elit. Phasellus nec nulla vel massa dignissim sagittis vitae vel ipsum. Cras aliquam lorem et erat pulvinar posuere. Duis tortor risus, sodales non neque at, auctor mollis dolor. Ut at ipsum tellus.</p>
                            <ul class="intro-list">
                                <li><a href="#">Residential Cleaning</a></li>
                                <li><a href="#">Office Cleaning</a></li>
                                <li><a href="#">Construction Cleaning</a></li>
                                <li><a href="#">Commercial Cleaning</a></li>
                                <li><a href="#">Wall Painting</a></li>
                                <li><a href="#">Seasonal Cleaning</a></li>
                            </ul>
                        </div><!-- about_content -->
                        <div class="about_fig">
                            <figure style="background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/images/intro.jpg);"></figure>
                        </div><!-- about_fig --><div class="clear"></div>
                    </div><!-- introduction box -->

                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>
        
        <!-- ***************************************************************************************** -->
        
        <section>
            <div class="container">                 
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="section_head">
                        <h4 class="section_sub_title">A Trusted Cleaning Company</h4>
                        <h2 class="section_title">High Quality &amp; Best Cleaning Services</h2>
                    </div>

                    <div class="one_third">
                        <div class="image-box">
                            <div class="image-box-thumb">
                                <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/service-1.jpg"></a>
                            </div>
                            <div class="image-box-content">
                                <div class="image-box-inner-content">
                                    <h4><a href="#">Window Cleaning</a></h4>
                                    <p> Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  </p>
                                    <a href="#" class="buttonstyle1">View Service</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="one_third">
                        <div class="image-box">
                            <div class="image-box-thumb">
                                <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/service-2.jpg"></a>
                            </div>
                            <div class="image-box-content">
                                <div class="image-box-inner-content">
                                    <h4><a href="#">Home Cleaning</a></h4>
                                    <p> Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  </p>
                                    <a href="#" class="buttonstyle1">View Service</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="one_third last_column">
                        <div class="image-box">
                            <div class="image-box-thumb">
                                <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/service-3.jpg"></a>
                            </div>
                            <div class="image-box-content">
                                <div class="image-box-inner-content">
                                    <h4><a href="#">Floor Cleaning</a></h4>
                                    <p> Pellentesque efficitur diam velit, non volutpat eros efficitur eget. Sed pretium eros quis leo tristique mollis.  </p>
                                    <a href="#" class="buttonstyle1">View Service</a>
                                </div>
                            </div>
                        </div>
                    </div><div class="clear"></div>

                </div><!-- .end section class --><div class="clear"></div>                 
            </div><!-- container -->
        </section>
        
        <!-- ***************************************************************************************** -->
        
        <section style="background-color:#27c9f7; " >           
            <div class="container">                 
                <div class="wow fadeInUp" data-wow-duration="1s">
                                            
                    <div class="counter-main">
                        <div class="counter-box" style="border-color:#ffffff;background-color:#27c9f7">   
                            <div class="inner-counter">
                                <h3 class="counter" style="color:#ffffff">600</h3><span style="color:#ffffff">+</span>
                                <h3 class="counter-ttl" style="color:#ffffff">Projects Finished</h3>
                            </div>
                        </div>
                        <div class="counter-box" style="border-color:#ffffff;background-color:#27c9f7">   
                            <div class="inner-counter">
                                <h3 class="counter" style="color:#ffffff">1450</h3><span style="color:#ffffff">+</span>
                                <h3 class="counter-ttl" style="color:#ffffff">Satisfied Customers</h3>
                            </div>
                        </div>
                        <div class="counter-box" style="border-color:#ffffff;background-color:#27c9f7">   
                            <div class="inner-counter">
                                <h3 class="counter" style="color:#ffffff">60</h3><span style="color:#ffffff">+</span>
                                <h3 class="counter-ttl" style="color:#ffffff">Branches Network</h3>
                            </div>
                        </div>
                        <div class="counter-box" style="border-color:#ffffff;background-color:#27c9f7">   
                            <div class="inner-counter">
                                <h3 class="counter" style="color:#ffffff">3000</h3><span style="color:#ffffff">+</span>
                                <h3 class="counter-ttl" style="color:#ffffff">Cleaning Tips</h3>
                            </div>
                        </div>
                        <div class="counter-box" style="border-color:#ffffff;background-color:#27c9f7">   
                            <div class="inner-counter">
                                <h3 class="counter" style="color:#ffffff">900</h3><span style="color:#ffffff">+</span>
                                <h3 class="counter-ttl" style="color:#ffffff">Free Quotes Sent</h3>
                            </div>
                        </div>
                    </div>
                    
                </div><!-- .end section class --><div class="clear"></div>                 
            </div><!-- container -->
        </section>
        
        <!-- ***************************************************************************************** -->
        
        <section style="background-color:#f8f8f8;">
            <div class="container">
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="section_head">
                        <h4 class="section_sub_title">Experienced &amp; Talented</h4>
                        <h2 class="section_title">Our Team</h2>
                    </div>

                    <div class="team-member-wrap">
                        <div class="teammember-list grid-col-four">
                            <div class="team-thumbnail">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/team1.jpg" alt="John Doe"/>
                                <div class="member-social-icon">
                                    <a href="#" title="facebook-f" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" title="linkedin" target="_blank"><i class="fab fa-linkedin"></i></a>
                                    <a href="#" title="instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                                    <a href="#" title="youtube" target="_blank"><i class="fab fa-youtube"></i></a>
                                </div><!-- member social icons -->
                            </div><!-- team thumbnail -->
                            <div class="team-content">
                                <div class="team-name">
                                    <h4><a href="#">John Doe</a></h4>
                                    <span>Cleaning Expert</span>
                                </div><!-- team name -->
                            </div><!-- team content -->
                        </div><!-- team member list -->

                    <div class="teammember-list grid-col-four ">
                        <div class="team-thumbnail">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/team2.jpg" alt="Martina Patrick"/>
                            <div class="member-social-icon">
                                <a href="#" title="facebook-f" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href="#" title="twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                                <a href="#" title="instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                                <a href="#" title="youtube" target="_blank"><i class="fab fa-youtube"></i></a>
                            </div><!-- member social icons -->
                        </div><!-- team thumbnail -->
                        <div class="team-content">
                            <div class="team-name">
                                <h4><a href="#">Martina Patrick</a></h4>
                                <span>Cleaning Expert</span>
                            </div><!-- team name -->
                        </div><!-- team content -->
                    </div><!-- team member list -->

                    <div class="teammember-list grid-col-four ">
                        <div class="team-thumbnail">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/team3.jpg" alt="Allan Doe"/>
                            <div class="member-social-icon">
                                <a href="#" title="facebook-f" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href="#" title="twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                                <a href="#" title="instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                                <a href="#" title="youtube" target="_blank"><i class="fab fa-youtube"></i></a>
                            </div><!-- member social icons -->
                        </div><!-- team thumbnail -->
                        <div class="team-content">
                            <div class="team-name">
                                <h4><a href="#">Allan Doe</a></h4>
                                <span>Cleaning Expert</span>
                            </div><!-- team name -->
                        </div><!-- team content -->
                    </div><!-- team member list -->

                    <div class="teammember-list grid-col-four  lastcols">
                        <div class="team-thumbnail">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/team4.jpg" alt="Christina Doe"/>
                            <div class="member-social-icon">
                                <a href="#" title="facebook-f" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href="#" title="twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                                <a href="#" title="instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                                <a href="#" title="youtube" target="_blank"><i class="fab fa-youtube"></i></a>
                            </div><!-- member social icons -->
                        </div><!-- team thumbnail -->
                        <div class="team-content">
                            <div class="team-name">
                                <h4><a href="#">Christina Doe</a></h4>
                                <span>Cleaning Expert</span>
                            </div><!-- team name -->
                        </div><!-- team content -->
                    </div><!-- team member list --><div class="clear"></div></div>

                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>

        <!-- ***************************************************************************************** -->
                        
        <section  class="pb-0">
            <div class="full-container">
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="section_head">
                        <h4 class="section_sub_title">Projects &amp; Portfolio</h4>
                        <h2 class="section_title">Our Gallery</h2>
                    </div>

                    <div class="gallery-wrap">
                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery1.jpg" alt="Gallery Image 1"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery1.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery1.jpg" data-caption="Gallery Image 1"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery2.jpg" alt="Gallery Image 2"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery2.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery2.jpg" data-caption="Gallery Image 2"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery3.jpg" alt="Gallery Image 3"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery3.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery3.jpg" data-caption="Gallery Image 3"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four lastcols">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery4.jpg" alt="Gallery Image 4"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery4.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery4.jpg" data-caption="Gallery Image 4"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery5.jpg" alt="Gallery Image 5"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery5.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery5.jpg" data-caption="Gallery Image 1"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery6.jpg" alt="Gallery Image 6"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery6.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery6.jpg" data-caption="Gallery Image 2"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery7.jpg" alt="Gallery Image 7"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery7.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery7.jpg" data-caption="Gallery Image 3"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="gallery grid-col-four lastcols">
                            <div class="gallery-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery8.jpg" alt="Gallery Image 8"/>
                                <div class="gal-icon">
                                    <a class="pop-gallery" data-fancybox="group3" data-thumb="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery8.jpg" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/gallery8.jpg" data-caption="Gallery Image 4"><i class="fal fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><div class="clear"></div></div>

                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>
        
        <!-- ***************************************************************************************** -->
                        
        <section style="background-color:#f8f8f8;">
            <div class="container">
                <div class="wow fadeInUp" data-wow-duration="1s">
                     
                    <div class="section_head">
                        <h4 class="section_sub_title">What Clients Say</h4>
                        <h2 class="section_title">Client Testimonials</h2>
                    </div>
                                            
                    <div id="clienttestiminials">
                        <div class="owl-carousel clienttestiminials owl-theme">
                            <div class="item">
                                <div class="testimonials-item">
                                    <div class="testi-content">
                                        <div class="testi-desc">
                                            <p>Morbi ac lorem at nulla cursus aliquam aliquam ut lectus. Praesent iaculis mollis pellentesque. Sed bibendum lobortis nisi sit amet hendrerit. Mauris tempor tincidunt dolor, vel tristique enim. Pellentesque vulputate tincidunt elit.</p>
                                        </div>
                                    </div>
                                    <div class="testi-namethumb">
                                        <div class="testi-thumb">
                                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testi1.png" alt="Brandon Doe"/>
                                        </div>
                                        <div class="tmttl">
                                            <h4><a href="#">Brandon Doe</a></h4>
                                            <span>(Some Company Name)</span>
                                        </div>
                                    </div><!-- testi-namethumb -->
                                </div>                          
                            </div>
                            <div class="item">
                                <div class="testimonials-item">
                                    <div class="testi-content">
                                        <div class="testi-desc">
                                            <p>Morbi ac lorem at nulla cursus aliquam aliquam ut lectus. Praesent iaculis mollis pellentesque. Sed bibendum lobortis nisi sit amet hendrerit. Mauris tempor tincidunt dolor, vel tristique enim. Pellentesque vulputate tincidunt elit.</p>
                                        </div>
                                    </div>
                                    <div class="testi-namethumb">
                                        <div class="testi-thumb">
                                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testi3.png" alt="John Doe"/>
                                        </div>
                                        <div class="tmttl">
                                            <h4><a href="#">John Doe</a></h4>
                                            <span>(Some Company Name)</span>
                                        </div>
                                    </div><!-- testi-namethumb -->
                                </div>                          
                            </div>
                            <div class="item">
                                <div class="testimonials-item">
                                    <div class="testi-content">
                                        <div class="testi-desc">
                                            <p>Morbi ac lorem at nulla cursus aliquam aliquam ut lectus. Praesent iaculis mollis pellentesque. Sed bibendum lobortis nisi sit amet hendrerit. Mauris tempor tincidunt dolor, vel tristique enim. Pellentesque vulputate tincidunt elit.</p>
                                        </div>
                                    </div>
                                    <div class="testi-namethumb">
                                        <div class="testi-thumb">
                                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testi2.png" alt="Alex Cartal"/>
                                        </div>
                                        <div class="tmttl">
                                            <h4><a href="#">Alex Cartal</a></h4>
                                            <span>(Some Company Name)</span>
                                        </div>
                                    </div><!-- testi-namethumb -->
                                </div>                          
                            </div>
                            <div class="item">
                                <div class="testimonials-item">
                                    <div class="testi-content">
                                        <div class="testi-desc">
                                            <p>Morbi ac lorem at nulla cursus aliquam aliquam ut lectus. Praesent iaculis mollis pellentesque. Sed bibendum lobortis nisi sit amet hendrerit. Mauris tempor tincidunt dolor, vel tristique enim. Pellentesque vulputate tincidunt elit.</p>
                                        </div>
                                    </div>
                                    <div class="testi-namethumb">
                                        <div class="testi-thumb">
                                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/testi1.png" alt="John Donald"/>
                                        </div>
                                        <div class="tmttl">
                                            <h4><a href="#">John Donald</a></h4>
                                            <span>(Some Company Name)</span>
                                        </div>
                                    </div><!-- testi-namethumb -->
                                </div>                          
                            </div>
                        </div>
                    </div>
                    
                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>
        
        <!-- ***************************************************************************************** -->
                        
        <section>
            <div class="container">
                <div class="wow fadeInUp" data-wow-duration="1s">

                    <div class="section_head">
                        <h4 class="section_sub_title">News &amp; Events</h4>
                        <h2 class="section_title">Our Latest Posts</h2>
                    </div>

                    <div class="latest-news-wrap">

                        <div class="news-box grid-col-three ">
                            <div class="news-thumb">
                                <figure class="news-thumb-wrap">
                                    <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/news1.jpg" alt="Aliquam gravida tincidunt viverra" /></a>
                                    <div class="post-date">09<span>Oct</span></div>
                                </figure>
                            </div>
                            <div class="news-content">
                                <div class="latest-news-para">
                                    <h3><a href="#">Aliquam gravida tincidunt viverra</a></h3>
                                    <div class="post-meta">
                                        <span class="post-auth">Written By <a href="#" title="Posts by admin" rel="author">admin</a></span>
                                        <span class="post-cate">In <a href="#" title="View all posts in Uncategorized">Uncategorized</a></span>
                                        <span class="post-comnt"><a href="#">No Comments</a></span>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque viverra, nibh id dictum dignissim, metus sapien posuere orci, id posuere est tortor id justo. Pellentesque dictum mauris et velit mollis, eget&#8230;</p>
                                    <a href="#" class="ln-read-more">Read More</a>
                                </div>
                            </div>
                        </div>

                        <div class="news-box grid-col-three ">
                            <div class="news-thumb">
                                <figure class="news-thumb-wrap">
                                    <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/news2.jpg" alt="lorem ipsum dolor" /></a>
                                    <div class="post-date">09<span>Oct</span></div>
                                </figure>
                            </div>
                            <div class="news-content">
                                <div class="latest-news-para">
                                    <h3><a href="#">lorem ipsum dolor</a></h3>
                                    <div class="post-meta">
                                        <span class="post-auth">Written By <a href="#" title="Posts by admin" rel="author">admin</a></span>
                                        <span class="post-cate">In <a href="#" title="View all posts in Uncategorized">Uncategorized</a></span>
                                        <span class="post-comnt"><a href="#">No Comments</a></span>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque viverra, nibh id dictum dignissim, metus sapien posuere orci, id posuere est tortor id justo. Pellentesque dictum mauris et velit mollis, eget&#8230;</p>
                                    <a href="#" class="ln-read-more">Read More</a>
                                </div>
                            </div>
                        </div>

                        <div class="news-box grid-col-three lastcols">
                            <div class="news-thumb">
                                <figure class="news-thumb-wrap">
                                    <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/news3.jpg" alt="Pellentesque non eros rutrum" /></a>
                                    <div class="post-date">09<span>Oct</span></div>
                                </figure>
                            </div>
                            <div class="news-content">
                                <div class="latest-news-para">
                                    <h3><a href="#">Pellentesque non eros rutrum</a></h3>
                                    <div class="post-meta">
                                        <span class="post-auth">Written By <a href="#" title="Posts by admin" rel="author">admin</a></span>
                                        <span class="post-cate">In <a href="#" title="View all posts in Uncategorized">Uncategorized</a></span>
                                        <span class="post-comnt"><a href="#">No Comments</a></span>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque viverra, nibh id dictum dignissim, metus sapien posuere orci, id posuere est tortor id justo. Pellentesque dictum mauris et velit mollis, eget&#8230;</p>
                                    <a href="#" class="ln-read-more">Read More</a>
                                </div>
                            </div>
                        </div><div class="clear"></div>

                    </div>

                </div><!-- .end section class --><div class="clear"></div>
            </div><!-- container -->
        </section>

        <!-- ***************************************************************************************** -->

        <div id="footer-wrapper">
            <div class="container">

                <div class='footer-cols-three'>
                    <div class="foo-cols widget-column">
                        <div id="flytheme-widget-getintouch-3" class="flytheme-widget-getintouch">
                            <div class="widget-space">
                                <div class="widget-getintouch">
                                    <h5 class="footer-widget-title">About Cleaning</h5>
                                    <p>Morbi ac lorem at nulla cursus aliquam aliquam ut lectus. Praesent iaculis mollis pellentesque. Sed bibendum lobortis nisi sit amet hendrerit. Mauris tempor tincidunt dolor, vel tristique enim. Pellentesque vulputate tincidunt elit, in fermentum dolor vehicula id. In sapien elit, consectetur sed vehicula et, luctus vitae nisi. Nam posuere ligula in mi interdum vestibulum. Cras ac sodales lorem. Nulla efficitur felis leo,</p>
                                    <ul class="widget-getintouch-social">
                                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="foo-cols widget-column">
                        <div id="nav_menu-2" class="widget_nav_menu">
                            <div class="widget-space">
                                <h5 class="footer-widget-title">Our Services</h5>
                                <div class="menu-main-menu-container">
                                    <ul id="menu-main-menu-2" class="menu">
                                        <li class="current-menu-item current_page_item"><a href="#" aria-current="page">Home</a></li>
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">Services</a></li>
                                        <li><a href="#">Pages</a></li>
                                        <li><a href="#">Gallery</a></li>
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="foo-cols widget-column">
                        <div id="flytheme-widget-getintouch-2" class="flytheme-widget-getintouch">
                            <div class="widget-space">
                                <div class="widget-getintouch">
                                    <h5 class="footer-widget-title">Contact Us</h5>
                                    <p>Praesent mollis non lorem at interdum. Cum sociis natoque penatibus et magnis dis parturient</p>
                                    <div class="foo-getintouch">
                                        <ul class="widget-getintouch-info">
                                            <li class="icon-address">1202, Cleaning Services sydney, Australia</li>
                                            <li class="icon-phone">+91 8888-888-8888 / +91 8888-888-6666</li>
                                            <li class="icon-fax">+91 8888-888-8888</li>
                                            <li class="icon-mail"><a href="mailto:support@sitename.com">support@sitename.com</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><div class="clear"></div>
                </div>

            </div><!--footer padding -->
        </div><!-- footer-wrapper -->

        <div class="copyright-wrapper">
            <div class="container">
                <div class="flex-element">
                    <div class="copyright-text">&copy; Copyright 2020. All Rights Reserved.</div>
                    <div class="designby-text">Theme Designed by <a href="http://www.flythemes.net/" target="_blank">Fly Themes</a>.</div>
                </div><!-- flex-element -->
            </div><!-- copyright padding -->
        </div><!-- copyright-wrapper -->

        <div id="back-top">
            <a title="Top of Page" href="#top"><span><i class="far fa-arrow-alt-circle-up" aria-hidden="true"></i></span></a>
        </div>
        
</div><!-- pagewrap -->

<script type="text/javascript">
jQuery(document).ready(function() {
	if(jQuery(window).width() >= 1170){
	  new WOW().init();
	}
});
</script>
</body>
</html>